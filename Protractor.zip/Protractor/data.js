exports.data = {
  url: 'https://accessidys.org',
//  url: 'https://accessidys.org/#/signup',
//  url: 'https://accessidys.org/#/?deconnexion=true',
  
//  url_bookmaklet: 'https://recette.accessidys.com/#/apercu?url=http:%2F%2Ffr.lipsum.com%2Ffeed%2Fhtml',
  url_bookmaklet: 'https://accessidys.org/#/apercu?url=https:%2F%2Ffr.wikipedia.org%2Fwiki%2FJules_Verne',


  // Compte Dropbox
  // mail_username: 'laurent.sumera@cgi.com',
  // mail_password: '123_cgi',
  mail_username: 'accessidys@gmail.com',
  mail_password: 'CnedAdapt',



  // Compte Accessidys
  //login: 'arthur.dupont86@gmail.com',
  //motDePasse: 'AccessiDys',
  login: 'accessidys@gmail.com',
  motDePasse: 'CnedAdapt',  

  // Creation de profil
  nomProfilAjout: 'AutoProfil',
  nomProfilAjoutSurligner: 'SurlignageLigne',
  nomProfilAjoutColorationSyllabique: 'ColorationSyllabique',
  nomProfilAjoutColorationLigne: 'ColorationLigne',

  // Consultation Profil
  nomProfilConsultationSurligner: 'SurlignageLigne',
  nomProfilConsultationColorationSyllabique: 'ColorationSyllabique',
  nomProfilConsultationColorationLigne: 'ColorationLigne',

  // Modification Profil
  nomProfilModif: 'AutoProfil',
  nomProfilModifie: 'AutoProfil2',

  // Delegation Profil
  nomProfilDelegue: 'AutoProfil2',

  // Suppression Profil
  nomProfilSuppr: 'AutoProfil2',
  
  // Modification Titre
  nTitre: 'JulesVerne2',
  aTitre: 'JulesVerne',
  
  // Modification document
  titreModif: 'DocAModifier',
  
  // Apercu Document
  apercuDocument: 'JulesVerne'
}
