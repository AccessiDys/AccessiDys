var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Apercu Profil', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var detailsProfils = require('../page/DetailsProfilsPage.js');
	var nomProfil = 'Accessidys par défaut';
	//var nomProfil = 'Cynthia';
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acces Apercu Profil', function() {
		menuPage.accederMesProfils();
		
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		mesProfils.actionApercu(nomProfil);
	});
// Titre 1	
	it('Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre1('opendyslexicregular');
	});
	
	it('Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre1(10);
	});
	
	it('Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre1(1);
	});
	
	it('Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre1();
	});
	
	it('Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre1(1);
	});
	
	it('Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre1(1);
	});
	
	it('Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(0);
	});
	
// Sous Titre 1
	it('Sous Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceSousTitre1('opendyslexicregular');
	});
	
	it('Sous Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleSousTitre1(10);
	});
	
	it('Sous Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneSousTitre1(1);
	});
	
	it('Sous Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasSousTitre1();
	});
	
	it('Sous Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsSousTitre1(1);
	});
	
	it('Sous Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresSousTitre1(1);
	});
	
	it('Sous Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationNoir(1);
	});
	
	// Titre 2
	it('Titre 2 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre2('opendyslexicregular');
	});
	
	it('Titre 2 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre2(10);
	});
	
	it('Titre 2 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre2(1);
	});
	
	it('Titre 2 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre2();
	});
	
	it('Titre 2 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre2(1);
	});
	
	it('Titre 2 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre2(1);
	});
	
	it('Titre 2 : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(2);
	});
	
	// Sous Titre 2
	it('Sous Titre 2 : Verifier Police', function() {
		detailsProfils.verifierPoliceSousTitre2('opendyslexicregular');
	});
	
	it('Sous Titre 2 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleSousTitre2(10);
	});
	
	it('Sous Titre 2 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneSousTitre2(1);
	});
	
	it('Sous Titre 2 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalSousTitre2();
	});
	
	it('Sous Titre 2 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsSousTitre2(1);
	});
	
	it('Sous Titre 2 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresSousTitre2(1);
	});
	
	it('Sous Titre 2 : Verifier Coloration', function() {
		detailsProfils.colorationNoir(3);
	});
	
	// Titre 3
	it('Titre 3 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre3('opendyslexicregular');
	});
	
	it('Titre 3 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre3(10);
	});
	
	it('Titre 3 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre3(1);
	});
	
	it('Titre 3 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalTitre3();
	});
	
	it('Titre 3 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre3(1);
	});
	
	it('Titre 3 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre3(1);
	});
	
	it('Titre 3 : Verifier Coloration', function() {
		detailsProfils.colorationNoir(4);
	});
	
		// Titre 4
	it('Titre 4 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre4('opendyslexicregular');
	});
	
	it('Titre 4 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre4(10);
	});
	
	it('Titre 4 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre4(1);
	});
	
	it('Titre 4 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre4();
	});
	
	it('Titre 4 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre4(1);
	});
	
	it('Titre 4 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre4(1);
	});
	
	it('Titre 4 : Verifier Coloration', function() {
		detailsProfils.colorationNoir(5);
	});

		// Paragraphe
	it('Paragraphe : Verifier Police', function() {
		detailsProfils.verifierPoliceParagraphe('opendyslexicregular');
	});
	
	it('Paragraphe : Verifier Taille Police', function() {
		detailsProfils.verifierTailleParagraphe(10);
	});
	
	it('Paragraphe : Verifier Interligne', function() {
		detailsProfils.verifierInterligneParagraphe(1);
	});
	
	it('Paragraphe : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalParagraphe();
	});
	
	it('Paragraphe : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsParagraphe(1);
	});
	
	it('Paragraphe : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresParagraphe(1);
	});
	
	it('Paragraphe : Verifier Coloration', function() {
		detailsProfils.colorationNoir(6);
	});
	
			// Annotation
	it('Annotation : Verifier Police', function() {
		detailsProfils.verifierPoliceAnnotation('opendyslexicregular');
	});
	
	it('Annotation : Verifier Taille Police', function() {
		detailsProfils.verifierTailleAnnotation(10);
	});
	
	it('Annotation : Verifier Interligne', function() {
		detailsProfils.verifierInterligneAnnotation(1);
	});
	
	it('Annotation : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalAnnotation();
	});
	
	it('Annotation : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsAnnotation(1);
	});
	
	it('Annotation : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresAnnotation(1);
	});
	
	it('Annotation : Verifier Coloration', function() {
		detailsProfils.colorationNoir(7);
	});
	
	// Citation
	it('Citation : Verifier Police', function() {
		detailsProfils.verifierPoliceCitation('opendyslexicregular');
	});
	
	it('Citation : Verifier Taille Police', function() {
		detailsProfils.verifierTailleCitation(10);
	});
	
	it('Citation : Verifier Interligne', function() {
		detailsProfils.verifierInterligneCitation(1);
	});
	
	it('Citation : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalCitation();
	});
	
	it('Citation : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsCitation(1);
	});
	
	it('Citation : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresCitation(1);
	});
	
	it('Citation : Verifier Coloration', function() {
		detailsProfils.colorationNoir(8);
	});
	
	// liste
	it('liste : Verifier Police', function() {
		detailsProfils.verifierPoliceListe('opendyslexicregular');
	});
	
	it('liste : Verifier Taille Police', function() {
		detailsProfils.verifierTailleListe(18);
	});
	
	it('liste : Verifier Interligne', function() {
		detailsProfils.verifierInterligneListe(1);
	});
	
	it('liste : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalListe();
	});
	
	it('liste : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsListe(2);
	});
	
	it('liste : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresListe(1);
	});
	
	it('liste : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(9);
	});
	
	// entetedepage
	it('entetedepage : Verifier Police', function() {
		detailsProfils.verifierPoliceEnteteDePage('opendyslexicregular');
	});
	
	it('entetedepage : Verifier Taille Police', function() {
		detailsProfils.verifierTailleEnteteDePage(10);
	});
	
	it('entetedepage : Verifier Interligne', function() {
		detailsProfils.verifierInterligneEnteteDePage(1);
	});
	
	it('entetedepage : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalEnteteDePage();
	});
	
	it('entetedepage : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsEnteteDePage(1);
	});
	
	it('entetedepage : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresEnteteDePage(1);
	});
	
	it('entetedepage : Verifier Coloration', function() {
		detailsProfils.colorationNoir(10);
	});
	
	// pieddepage
	it('pieddepage : Verifier Police', function() {
		detailsProfils.verifierPolicePiedDePage('opendyslexicregular');
	});
	
	it('pieddepage : Verifier Taille Police', function() {
		detailsProfils.verifierTaillePiedDePage(10);
	});
	
	it('pieddepage : Verifier Interligne', function() {
		detailsProfils.verifierInterlignePiedDePage(1);
	});
	
	it('pieddepage : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalPiedDePage();
	});
	
	it('pieddepage : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsPiedDePage(1);
	});
	
	it('pieddepage : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresPiedDePage(1);
	});
	
	it('pieddepage : Verifier Coloration', function() {
		detailsProfils.colorationNoir(11);
	});
	
	// Legende
	it('Legende : Verifier Police', function() {
		detailsProfils.verifierPoliceLegende('opendyslexicregular');
	});
	
	it('Legende : Verifier Taille Police', function() {
		detailsProfils.verifierTailleLegende(10);
	});
	
	it('Legende : Verifier Interligne', function() {
		detailsProfils.verifierInterligneLegende(1);
	});
	
	it('Legende : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalLegende();
	});
	
	it('Legende : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsLegende(1);
	});
	
	it('Legende : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresLegende(1);
	});
	
	it('Legende : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(12);
	});
});
