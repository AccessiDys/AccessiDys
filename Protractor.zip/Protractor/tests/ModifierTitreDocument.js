describe('AccessiDys : Modifier Titre Document', function() {
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var nouveauTitre = data.nTitre;
	var titreDocument = data.aTitre;
	
	//accès au site et la deconnexion une fois les taches terminées
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	it('Rechercher Document', function() {
		listeDocuments.rechercher(titreDocument);
		listeDocuments.documentUnique();  
	});
	
	it('Modifier Titre', function() {
		//processus de modification du titre
		listeDocuments.actionModifierTitre(titreDocument);
	});
		
	it('Renseigner Titre et Valider', function() {
		listeDocuments.rentrerNouveauTitre(nouveauTitre);
		listeDocuments.actionRenommer();
	});
		
	it('Recherche du document avec le nouveau titre', function() {
		listeDocuments.rechercher(nouveauTitre);
		listeDocuments.documentUnique();  
		
	});
		
	it('Modification vers l ancien titre', function() {
		//vérification
		listeDocuments.actionModifierTitre(nouveauTitre);
		listeDocuments.rentrerNouveauTitre(titreDocument);
		listeDocuments.actionRenommer();
		listeDocuments.rechercher(titreDocument);
		listeDocuments.documentUnique();  
	
	});
});
