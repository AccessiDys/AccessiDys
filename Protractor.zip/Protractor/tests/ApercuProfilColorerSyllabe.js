var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Apercu Profil Coloration Syllabe', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var detailsProfils = require('../page/DetailsProfilsPage.js');
	var nomProfil = data.nomProfilConsultationColorationSyllabique;
	//var nomProfil = 'Cynthia';
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acces Apercu Profil', function() {
		menuPage.accederMesProfils();
		
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		mesProfils.actionApercu(nomProfil);
	});
// Titre 1	
	it('Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre1('opendyslexicregular');
	});
	
	it('Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre1(24);
	});
	
	it('Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre1(4);
	});
	
	it('Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre1();
	});
	
	it('Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre1(4);
	});
	
	it('Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre1(4);
	});
	
	it('Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(0);
	});
	
// Sous Titre 1
	it('Sous Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceSousTitre1('Arial');
	});
	
	it('Sous Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleSousTitre1(10);
	});
	
	it('Sous Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneSousTitre1(3);
	});
	
	it('Sous Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalSousTitre1();
	});
	
	it('Sous Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsSousTitre1(5);
	});
	
	it('Sous Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresSousTitre1(2);
	});
	
	it('Sous Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(1);
	});
	
	// Titre 2
	it('Titre 2 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre2('opendyslexicregular');
	});
	
	it('Titre 2 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre2(18);
	});
	
	it('Titre 2 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre2(1);
	});
	
	it('Titre 2 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre2();
	});
	
	it('Titre 2 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre2(1);
	});
	
	it('Titre 2 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre2(1);
	});
	
	it('Titre 2 : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(2);
	});
	
	
	// Titre 3
	it('Titre 3 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre3('opendyslexicregular');
	});
	
	it('Titre 3 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre3(14);
	});
	
	it('Titre 3 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre3(1);
	});
	
	it('Titre 3 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre3();
	});
	
	it('Titre 3 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre3(1);
	});
	
	it('Titre 3 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre3(1);
	});
	
	it('Titre 3 : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(4);
	});
	
		
		// Paragraphe
	it('Paragraphe : Verifier Police', function() {
		detailsProfils.verifierPoliceParagraphe('opendyslexicregular');
	});
	
	it('Paragraphe : Verifier Taille Police', function() {
		detailsProfils.verifierTailleParagraphe(10);
	});
	
	it('Paragraphe : Verifier Interligne', function() {
		detailsProfils.verifierInterligneParagraphe(3);
	});
	
	it('Paragraphe : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalParagraphe();
	});
	
	it('Paragraphe : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsParagraphe(4);
	});
	
	it('Paragraphe : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresParagraphe(1);
	});
	
	it('Paragraphe : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(6);
	});
	
			// Annotation
	it('Annotation : Verifier Police', function() {
		detailsProfils.verifierPoliceAnnotation('Arial');
	});
	
	it('Annotation : Verifier Taille Police', function() {
		detailsProfils.verifierTailleAnnotation(9);
	});
	
	it('Annotation : Verifier Interligne', function() {
		detailsProfils.verifierInterligneAnnotation(2);
	});
	
	it('Annotation : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalAnnotation();
	});
	
	it('Annotation : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsAnnotation(4);
	});
	
	it('Annotation : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresAnnotation(2);
	});
	
	it('Annotation : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(2);
	});
	
	// Citation
	it('Citation : Verifier Police', function() {
		detailsProfils.verifierPoliceCitation('Arial');
	});
	
	it('Citation : Verifier Taille Police', function() {
		detailsProfils.verifierTailleCitation(9);
	});
	
	it('Citation : Verifier Interligne', function() {
		detailsProfils.verifierInterligneCitation(2);
	});
	
	it('Citation : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalCitation();
	});
	
	it('Citation : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsCitation(9);
	});
	
	it('Citation : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresCitation(10);
	});
	
	it('Citation : Verifier Coloration', function() {
		detailsProfils.colorationMotRGB(8);
	});
	
});
