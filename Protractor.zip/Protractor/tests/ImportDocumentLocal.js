var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Import Document Local', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var ajouterDocument = require('../page/AjouterDocumentPage.js')
	var ouvrirDocument = require('../page/OuvrirDocumentPage.js')
		
	var nomProfilAjoutSurligner = data.nomProfilAjoutSurligner;
	var nomProfilAjoutColorationSyllabique = data.nomProfilAjoutColorationSyllabique;
	var nomProfilAjoutColorationLigne = data.nomProfilAjoutColorationLigne;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	it('Selectionner Profil 1', function() {
		menuPage.selectionnerProfil(nomProfilAjoutSurligner);
	});
		
	it('ajouter Document', function() {
		listeDocuments.cliquerSurAjouterDocument();
		//ajouterDocument.renseignerTitre('testCGI');
	});
		
	it('Ouvrir Document', function() {
		ajouterDocument.cliquerSurOuvrirDocument();
		//ouvrirDocument.renseignerTitre('ExempleCGI');
		//ouvrirDocument.renseignerChemin('ExempleCGI.pdf');
		ouvrirDocument.renseignerChemin('pirandelloignorantes2.epub');
	});
		
	it('Cliquer sur Ouvrir', function() {
		ouvrirDocument.cliquerSurOuvrir();
		ajouterDocument.zoneTextNonVide();
	});
		

		
	it('Verifier Import profil 1 coloration Titre1', function() {
		ajouterDocument.surlignageMotTitre1();
	});

	
		
	it('Verifier Import profil 1 coloration Paragraphe', function() {
		ajouterDocument.surlignageMotParagraphe();
	});
		
	
	
	//--------------------------------------------------------------------
	
	it('Selectionner Profil 2', function() {
		menuPage.selectionnerProfil(nomProfilAjoutColorationSyllabique);
	});
	
	it('Verifier Import profil 2 coloration Titre1', function() {
		ajouterDocument.alternerCouleurMotTitre1();
	});
	
		
	it('Verifier Import profil 2 coloration Paragraphe', function() {
		ajouterDocument.alternerCouleurMotParagraphe();
	});
	
	//--------------------------------------------------------------------
	
	it('Selectionner Profil 3', function() {
		menuPage.selectionnerProfil(nomProfilAjoutColorationLigne);
	});
	
	it('Verifier Import profil 3 coloration Titre1', function() {
		ajouterDocument.colorationLigneRBVTitre1();
	});
	
		
	it('Verifier Import profil 3 coloration Paragraphe', function() {
		ajouterDocument.colorationLigneRBVParagraphe();
	});
	
});
