var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Import Document Web', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var ajouterDocument = require('../page/AjouterDocumentPage.js')
	var ouvrirDocument = require('../page/OuvrirDocumentPage.js')
	var titreDocument = 'ExempleCGI';
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	it('Ajouter Document', function() {
		listeDocuments.cliquerSurAjouterDocument();
	});
		  
	it('Renseigner Titre', function() {
		ajouterDocument.renseignerTitre(titreDocument);
	 });
	 
	it('Ouvrir Document', function() {
		ajouterDocument.cliquerSurOuvrirDocument();
	});
	  
	it('Renseigner le titre et l\'URl', function() {
		ouvrirDocument.renseignerTitre(titreDocument);
		ouvrirDocument.renseignerURL('http://www.loremipsum.net');
	});
	  
	it('Valider Ouvrir Document', function() {
		ouvrirDocument.cliquerSurOuvrir();
	});
	  
	it('Verifier que le document est chargé', function() {
		ajouterDocument.zoneTextNonVide();
	});
		  
	it('Enregistrer', function() {
		ajouterDocument.cliquerSurEnregistrer();
	});
	  
	it('Fermer', function() {
		ajouterDocument.cliquerSurFermer();
	});
	  
	it('Verifier la présence du Document', function() {	
		listeDocuments.rechercher(titreDocument);
		listeDocuments.documentUnique();  
	});
	
	xit('Supprimer le Document', function() {	
		listeDocuments.actionSupprimer(titreDocument);
		listeDocuments.ValiderSuppression();  
		listeDocuments.rechercher(titreDocument);
		listeDocuments.documentInexistant(); 
	});
});
