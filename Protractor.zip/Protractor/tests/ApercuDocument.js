var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Apercu Document', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var afficherDocuments = require('../page/AfficherDocumentPage.js');
	var nomProfil = 'Accessidys par défaut';
	var nomDocument = data.apercuDocument;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Selectionner Profil', function() {
		menuPage.selectionnerProfil(nomProfil);
	});
		
	it('Afficher Document', function() {
		menuPage.selectionnerProfil(nomProfil);
		listeDocuments.afficher(nomDocument);
	});
		
	it('Verifier Coloration Titre1', function() {
		afficherDocuments.colorationLigneRBVTitre1();
	});
		
	it('Verifier Coloration Titre2', function() {
		afficherDocuments.alternerCouleurMotTitre2();
	});
});
