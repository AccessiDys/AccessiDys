var randVal = Date.now();

describe('AccessiDys : Mise à jour du document', function() {
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var modifierDocument = require('../page/ModifierDocumentPage.js');
	var titreDocument = data.titreModif;
	var message = 'Modification' + randVal;
	
	//accès au site et la deconnexion une fois les taches terminées
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Modifier le document', function() {
		//processus de modification du document
		listeDocuments.modifier(titreDocument);
	});
		
	it('Renseigner un texte', function() {
		modifierDocument.renseignerTexte(message);
	});
		
	it('Enregistrer et fermer le document', function() {
		modifierDocument.cliquerSurEnregistrer();
		modifierDocument.cliquerSurFermer(); 
	});
		
	it('Verifier Modification', function() {	
		//vérification
		listeDocuments.modifier(titreDocument);
		modifierDocument.actionVerification(message);
		modifierDocument.cliquerSurFermer();  
	});
});