var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Apercu Profil Surligner', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var detailsProfils = require('../page/DetailsProfilsPage.js');
	var nomProfil = data.nomProfilConsultationSurligner;
	//var nomProfil = 'Cynthia';
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acces Apercu Profil', function() {
		menuPage.accederMesProfils();
		
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		mesProfils.actionApercu(nomProfil);
	});

	
	// Titre 1	
	it('Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre1('Arial');
	});
	
	it('Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre1(36);
	});
	
	it('Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre1(5);
	});
	
	it('Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre1();
	});
	
	it('Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre1(8);
	});
	
	it('Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre1(1);
	});
	
	it('Titre 1 : Verifier Coloration', function() {
		detailsProfils.surlignerMot(0);
	});
	
	
	// Titre 2
	it('Titre 2 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre2('Times New Roman');
	});
	
	it('Titre 2 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre2(18);
	});
	
	it('Titre 2 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre2(2);
	});
	
	it('Titre 2 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseGrasTitre2();
	});
	
	it('Titre 2 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre2(5);
	});
	
	it('Titre 2 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre2(1);
	});
	
	it('Titre 2 : Verifier Coloration', function() {
		detailsProfils.surlignerMot(2);
	});
	


	// Paragraphe
	it('Paragraphe : Verifier Police', function() {
		detailsProfils.verifierPoliceParagraphe('Arial');
	});
	
	it('Paragraphe : Verifier Taille Police', function() {
		detailsProfils.verifierTailleParagraphe(16);
	});
	
	it('Paragraphe : Verifier Interligne', function() {
		detailsProfils.verifierInterligneParagraphe(5);
	});
	
	it('Paragraphe : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalParagraphe();
	});
	
	it('Paragraphe : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsParagraphe(2);
	});
	
	it('Paragraphe : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresParagraphe(3);
	});
	
	it('Paragraphe : Verifier Coloration', function() {
		detailsProfils.surlignerMot(6);
	});
	
	
});
