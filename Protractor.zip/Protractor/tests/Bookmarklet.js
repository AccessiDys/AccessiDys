var fs = require('fs');
var randVal = Date.now();

describe('Bookmarklet', function() {
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var bookmarklet  = require('../page/BookmarkletPage.js');	
	
  it('Charger le bookmark', function() {
    //browser.addMockModule('disableNgAnimate', disableNgAnimate);

	
	//var loginPage = new LoginPage();
	
	/*loginPage.renseignerEmail(data.login);
	loginPage.renseignerMdp(data.motDePasse);
	loginPage.cliquerSurSeConnecter();*/
    /* Register */
  // browser.wait(10000);
  
	browser.get(data.url_bookmaklet);
	bookmarklet.attendreAffichage();
	bookmarklet.verifierNonVide();
  });
});
