var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Modifier Profil', function() {
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js')
	var modifierProfil = require('../page/ModifierProfilPage.js')
	var nomProfil = data.nomProfilModif;
	var nouveauNomProfil = data.nomProfilModifie;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});
			
	it('Rechercher Profil', function() {	
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
	});
			
	it('Modifier Profil', function() {
		mesProfils.actionModifier(nomProfil);
	});
			
	it('Modifier Détail Profil', function() {	
		ajouterProfil.CliquerSurModifierProfil();
	});
			
	it('Renseigner Nom', function() {	
		modifierProfil.modifierNom(nouveauNomProfil);
		modifierProfil.enregistrer();
	});
			
	it('Enregistrer Modification', function() {	
		ajouterProfil.CliquerSurEnregistrerProfilModif();
		
		//mesProfils.ajoutOK();
		
		//menuPage.accederMesProfils();
	});
			
	it('Verifier Modification du Profil', function() {	
		mesProfils.attendreAffichage();
		mesProfils.rechercher(nouveauNomProfil);
		mesProfils.ProfilUnique();
		
		menuPage.ProfilActuelExistant(nouveauNomProfil);
	});
});
