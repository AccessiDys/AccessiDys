var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Creation Compte', function() {
	
	beforeAll(function(){
		 browser.get(data.url);
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	var loginPage = require('../page/LoginPage.js');	
	var inscriptionPage = require('../page/InscriptionPage.js');
	var compteDropboxPage = require('../page/CompteDropboxPage.js');
	var menuPage  = require('../page/MenuPage.js');	
	
  it('Acces à la creation de compte', function() {
	
	loginPage.cliquerSurCreerCompte();
	
  });
  
  it('Acces à la creation de compte', function() {
	inscriptionPage.renseignerPrenom('prenom-' + randVal);
	inscriptionPage.renseignerNom('nom-' + randVal);
	inscriptionPage.renseignerEmail('email-' + randVal + '@cgi.com');
	inscriptionPage.renseignerMdp('test1test');
	inscriptionPage.renseignerConfMdp('test1test');

	inscriptionPage.cliquerSurSuivant();
  });
  
  it('Popup Validation', function() {

	compteDropboxPage.cliquerSurOk();
	
	//browser.wait( EC.invisibilityOf(element(by.id('myModal'))), 5000 );
	
	compteDropboxPage.cliquerSurSuivant();
  });
  
  it('Association DropBox', function() {
    /* Dropbox */
    isAngularSite(false);
    $('input[name=login_email]').sendKeys(data.mail_username);
    $('input[name=login_password]').sendKeys(data.mail_password);
    $('button[class="login-button button-primary"]').click();

    //isAngularSite(true);
  });
  
  it('Ecran de confirmation Dropbox', function() {
	browser.sleep(5000);  
    inscriptionPage.cliquerSuivantConfirmation();
	isAngularSite(true);
  });
  /*
  xit('Ecran de Favoris', function() {
	browser.sleep(2000);
    inscriptionPage.cliquerSuivantConfirmation();
  });
  
  xit('Ecran de Favoris', function() {
    inscriptionPage.cliquerSuivantFavoris();
  });
  */
  it('Affichage de la page Mes Documents', function() {
	  browser.sleep(2000);
	menuPage.accederMesDocuments();
  });
});
