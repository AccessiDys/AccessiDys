var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Creer Document', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var listeDocuments = require('../page/ListeDocumentsPage.js');
	var ajouterDocument = require('../page/AjouterDocumentPage.js')
	var ouvrirDocument = require('../page/OuvrirDocumentPage.js')
	var nomDoc = 'testCGI' + randVal;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Ajouter Document', function() {
		listeDocuments.cliquerSurAjouterDocument();
	});
		
	it('Renseigner document et Enregistrer', function() {
		ajouterDocument.renseignerTitre(nomDoc);
		ajouterDocument.setText('Test de modification du texte');
		ajouterDocument.cliquerSurEnregistrer();
	});
		
	it('Fermer Document', function() {	
		ajouterDocument.cliquerSurFermer();
	});
		
	it('Verifier creation Document', function() {	
		listeDocuments.rechercher(nomDoc);
	});
		
	it('Modifier Document', function() {	
		listeDocuments.modifier(nomDoc);
	});
		
	it('Verifier Ecart', function() {
		ajouterDocument.zoneTextNonVide();
	});
	
});
