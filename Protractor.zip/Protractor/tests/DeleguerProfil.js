var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Deleguer Profil', function() {
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js')
	var modifierProfil = require('../page/ModifierProfilPage.js')
	var nomProfil = data.nomProfilDelegue;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});
	
	it('Rechercher profil', function() {		
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
	});
	
	it('Deleguer profil', function() {		
		mesProfils.actionDeleguer(nomProfil);
	});
	
	it('Renseigner Email', function() {
		//browser.pause();
		mesProfils.renseignerEmail('test@gmail.com');
		mesProfils.envoyerEmail();
		//mesProfils.ajoutOK();
	});
	
	it('Annuler Délégation', function() {		
		//menuPage.accederMesProfils();
		mesProfils.attendreAffichage();
		mesProfils.actionAnnulerDeleguation(nomProfil);
		mesProfils.cliquerSurOui();
		mesProfils.attendreAffichage();
		
		//menuPage.accederMesProfils();
		//mesProfils.attendreAffichage();
	});
});
