var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Ajouter Profil Surligner', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var modifierStyle = require('../page/ModifierValeurStylePage.js');
	var nomProfil = data.nomProfilAjoutSurligner;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});	
	
	it('Rechercher Profil', function() {
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilInexistant();
	});

	it('Ajouter Profil', function() {
		mesProfils.cliquerSurAjouterProfil();
	});
	
	it('Mofifier Nom Profil', function() {
		ajouterProfil.CliquerSurModifierProfil();
	});
	
	it('Renseigner Nom', function() {
		modifierProfil.renseignerNom(nomProfil);
		modifierProfil.enregistrer();
	});
	
	it('Mofifier Titre 1', function() {
		ajouterProfil.modifierStyleTitre1Creation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(36);
		modifierStyle.selectionnerInterligne(5);
		modifierStyle.selectionnerColoration('Surligner les mots');
		modifierStyle.selectionnerGraisse('Gras');
		modifierStyle.selectionnerEspaceMots(8);
		modifierStyle.selectionnerEspaceCaracteres(1);
		modifierStyle.enregistrer();
		
	});
	
	it('Mofifier Titre 2', function() {
		ajouterProfil.modifierStyleTitre2Creation();
		modifierStyle.selectionnerPolice('Times New Roman');
		modifierStyle.selectionnerTaille(18);
		modifierStyle.selectionnerInterligne(2);
		modifierStyle.selectionnerColoration('Surligner les mots');
		modifierStyle.selectionnerGraisse('Gras');
		modifierStyle.selectionnerEspaceMots(5);
		modifierStyle.selectionnerEspaceCaracteres(1);
		modifierStyle.enregistrer();
		
	});
	
	it('Mofifier Paragraphe', function() {
		ajouterProfil.modifierStyleParagrapheCreation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(16);
		modifierStyle.selectionnerInterligne(5);
		modifierStyle.selectionnerColoration('Surligner les mots');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(2);
		modifierStyle.selectionnerEspaceCaracteres(3);
		modifierStyle.enregistrer();
		
	});
	
	it('Enregistrer Profil', function() {
		ajouterProfil.CliquerSurEnregistrerProfil();
	});
	
		//mesProfils.ajoutOK();
		//menuPage.accederMesProfils();
	
	it('Verifier Creation Profil', function() {	
		mesProfils.attendreAffichage();
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		
		menuPage.ProfilActuelExistant(nomProfil);
	});
});
