var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Ajouter Profil Coloration Ligne', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var modifierStyle = require('../page/ModifierValeurStylePage.js');
	var nomProfil = data.nomProfilAjoutColorationLigne;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});	
	
	it('Rechercher Profil', function() {
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilInexistant();
	});

	it('Ajouter Profil', function() {
		mesProfils.cliquerSurAjouterProfil();
	});
	
	it('Modifier Nom Profil', function() {
		ajouterProfil.CliquerSurModifierProfil();
	});
	
	it('Renseigner Nom', function() {
		modifierProfil.renseignerNom(nomProfil);
		modifierProfil.enregistrer();
	});
	
	it('Modifier Titre 1', function() {
		ajouterProfil.modifierStyleTitre1Creation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(28);
		modifierStyle.selectionnerInterligne(6);
		modifierStyle.selectionnerColoration('Colorer les lignes RBV');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(2);
		modifierStyle.selectionnerEspaceCaracteres(2);
		modifierStyle.enregistrer();	
	});
	
	it('Modifier Sous Titre 1', function() {
		ajouterProfil.modifierStyleSousTitre1Creation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(18);
		modifierStyle.selectionnerInterligne(4);
		modifierStyle.selectionnerColoration('Colorer les lignes RBV');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(2);
		modifierStyle.selectionnerEspaceCaracteres(2);
		modifierStyle.enregistrer();	
	});
	
	it('Modifier Paragraphe', function() {
		ajouterProfil.modifierStyleParagrapheCreation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(18);
		modifierStyle.selectionnerInterligne(6);
		modifierStyle.selectionnerColoration('Colorer les lignes RBV');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(2);
		modifierStyle.selectionnerEspaceCaracteres(2);
		modifierStyle.enregistrer();	
	});
	
	it('Enregistrer Profil', function() {
		ajouterProfil.CliquerSurEnregistrerProfil();
	});
	
		//mesProfils.ajoutOK();
		//menuPage.accederMesProfils();
	
	it('Verifier Creation Profil', function() {	
		mesProfils.attendreAffichage();
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		
		menuPage.ProfilActuelExistant(nomProfil);
	});
});
