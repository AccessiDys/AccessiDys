var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Ajouter Profil Coloration Syllabe', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var modifierStyle = require('../page/ModifierValeurStylePage.js');
	var nomProfil = data.nomProfilAjoutColorationSyllabique;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});	
	
	it('Rechercher Profil', function() {
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilInexistant();
	});

	it('Ajouter Profil', function() {
		mesProfils.cliquerSurAjouterProfil();
	});
	
	it('Modifier Nom Profil', function() {
		ajouterProfil.CliquerSurModifierProfil();
	});
	
	it('Renseigner Nom', function() {
		modifierProfil.renseignerNom(nomProfil);
		modifierProfil.enregistrer();
	});
	
	it('Modifier Titre 1', function() {
		ajouterProfil.modifierStyleTitre1Creation();
		modifierStyle.selectionnerPolice('opendyslexicregular');
		modifierStyle.selectionnerTaille(24);
		modifierStyle.selectionnerInterligne(4);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Gras');
		modifierStyle.selectionnerEspaceMots(4);
		modifierStyle.selectionnerEspaceCaracteres(4);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Sous Titre 1', function() {
		ajouterProfil.modifierStyleSousTitre1Creation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(10);
		modifierStyle.selectionnerInterligne(3);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(5);
		modifierStyle.selectionnerEspaceCaracteres(2);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Titre 2', function() {
		ajouterProfil.modifierStyleTitre2Creation();
		modifierStyle.selectionnerPolice('opendyslexicregular');
		modifierStyle.selectionnerTaille(18);
		modifierStyle.selectionnerInterligne(1);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Gras');
		modifierStyle.selectionnerEspaceMots(1);
		modifierStyle.selectionnerEspaceCaracteres(1);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Titre 3', function() {
		ajouterProfil.modifierStyleTitre3Creation();
		modifierStyle.selectionnerPolice('opendyslexicregular');
		modifierStyle.selectionnerTaille(14);
		modifierStyle.selectionnerInterligne(1);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Gras');
		modifierStyle.selectionnerEspaceMots(1);
		modifierStyle.selectionnerEspaceCaracteres(1);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Paragraphe', function() {
		ajouterProfil.modifierStyleParagrapheCreation();
		modifierStyle.selectionnerPolice('opendyslexicregular');
		modifierStyle.selectionnerTaille(10);
		modifierStyle.selectionnerInterligne(3);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(4);
		modifierStyle.selectionnerEspaceCaracteres(1);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Annotation', function() {
		ajouterProfil.modifierStyleAnnotationCreation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(9);
		modifierStyle.selectionnerInterligne(2);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(4);
		modifierStyle.selectionnerEspaceCaracteres(2);
		modifierStyle.enregistrer();
	});
	
	it('Modifier Citation', function() {
		ajouterProfil.modifierStyleCitationCreation();
		modifierStyle.selectionnerPolice('Arial');
		modifierStyle.selectionnerTaille(9);
		modifierStyle.selectionnerInterligne(2);
		modifierStyle.selectionnerColoration('Colorer les syllabes');
		modifierStyle.selectionnerGraisse('Normal');
		modifierStyle.selectionnerEspaceMots(9);
		modifierStyle.selectionnerEspaceCaracteres(10);
		modifierStyle.enregistrer();
	});

	it('Enregistrer Profil', function() {
		ajouterProfil.CliquerSurEnregistrerProfil();
	});
	
		//mesProfils.ajoutOK();
		//menuPage.accederMesProfils();
	
	it('Verifier Creation Profil', function() {	
		mesProfils.attendreAffichage();
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		
		menuPage.ProfilActuelExistant(nomProfil);
	});
});
