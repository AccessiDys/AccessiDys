var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Apercu Profil Coloration Ligne', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js');
	var modifierProfil = require('../page/ModifierProfilPage.js');
	var detailsProfils = require('../page/DetailsProfilsPage.js');
	var nomProfil = data.nomProfilConsultationColorationLigne;
	//var nomProfil = 'Cynthia';
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acces Apercu Profil', function() {
		menuPage.accederMesProfils();
		
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		mesProfils.actionApercu(nomProfil);
	});
	
// Titre 1	
	it('Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceTitre1('Arial');
	});
	
	it('Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleTitre1(28);
	});
	
	it('Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneTitre1(6);
	});
	
	it('Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalTitre1();
	});
	
	it('Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsTitre1(2);
	});
	
	it('Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresTitre1(2);
	});
	
	it('Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(0);
	});
	
// Sous Titre 1
	it('Sous Titre 1 : Verifier Police', function() {
		detailsProfils.verifierPoliceSousTitre1('Arial');
	});
	
	it('Sous Titre 1 : Verifier Taille Police', function() {
		detailsProfils.verifierTailleSousTitre1(18);
	});
	
	it('Sous Titre 1 : Verifier Interligne', function() {
		detailsProfils.verifierInterligneSousTitre1(4);
	});
	
	it('Sous Titre 1 : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalSousTitre1();
	});
	
	it('Sous Titre 1 : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsSousTitre1(2);
	});
	
	it('Sous Titre 1 : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresSousTitre1(2);
	});
	
	it('Sous Titre 1 : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(1);
	});
	

		// Paragraphe
	it('Paragraphe : Verifier Police', function() {
		detailsProfils.verifierPoliceParagraphe('Arial');
	});
	
	it('Paragraphe : Verifier Taille Police', function() {
		detailsProfils.verifierTailleParagraphe(18);
	});
	
	it('Paragraphe : Verifier Interligne', function() {
		detailsProfils.verifierInterligneParagraphe(6);
	});
	
	it('Paragraphe : Verifier Graisse', function() {
		detailsProfils.verifierGraisseNormalParagraphe();
	});
	
	it('Paragraphe : Verifier Espace Mot', function() {
		detailsProfils.verifierEspaceMotsParagraphe(2);
	});
	
	it('Paragraphe : Verifier Espace caracteres', function() {
		detailsProfils.verifierEspaceCaracteresParagraphe(2);
	});
	
	it('Paragraphe : Verifier Coloration', function() {
		detailsProfils.colorationLigneRBV(6);
	});
	
});
