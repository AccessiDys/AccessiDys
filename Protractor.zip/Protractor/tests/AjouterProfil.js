var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Ajouter Profil', function() {
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js')
	var modifierProfil = require('../page/ModifierProfilPage.js')
	var nomProfil = data.nomProfilAjout;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
		
	it('Acceder à Mes Profils', function() {
		menuPage.accederMesProfils();
	});	
	
	it('Rechercher Profil', function() {
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilInexistant();
	});

	it('Ajouter Profil', function() {
		mesProfils.cliquerSurAjouterProfil();
	});
	
	it('Mofifier Profil', function() {
		ajouterProfil.CliquerSurModifierProfil();
	});
	
	it('Renseigner Nom', function() {
		modifierProfil.renseignerNom(nomProfil);
		modifierProfil.enregistrer();
	});
	
	it('Enregistrer Profil', function() {
		ajouterProfil.CliquerSurEnregistrerProfil();
	});
	
		//mesProfils.ajoutOK();
		//menuPage.accederMesProfils();
	
	it('Verifier Creation Profil', function() {	
		mesProfils.attendreAffichage();
		mesProfils.rechercher(nomProfil);
		mesProfils.ProfilUnique();
		
		menuPage.ProfilActuelExistant(nomProfil);
	});
});
