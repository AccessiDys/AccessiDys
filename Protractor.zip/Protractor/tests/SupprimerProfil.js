var fs = require('fs');
var randVal = Date.now();

describe('AccessiDys : Supprimer Profil', function() {
	
	var loginPage = require('../page/LoginPage.js');	
	var menuPage  = require('../page/MenuPage.js');	
	var mesProfils = require('../page/MesProfilsPage.js');
	var ajouterProfil = require('../page/AjouterProfilPage.js')
	var modifierProfil = require('../page/ModifierProfilPage.js')
	var nomProfil = data.nomProfilSuppr ;
	
	beforeAll(function(){
		browser.get(data.url);
		loginPage.renseignerEmail(data.login);
		loginPage.renseignerMdp(data.motDePasse);
		loginPage.cliquerSurSeConnecter();
	});
	
	afterAll(function(){
		menuPage.accederSeDeconnecter();
	});
	
  it('Acceder à Mes profils', function() {
	menuPage.accederMesProfils();
	});
	
  it('Rechercher profil', function() {	
	mesProfils.rechercher(nomProfil);
	mesProfils.ProfilUnique();
	});
	
  it('Supprimer profil', function() {	
	mesProfils.actionSupprimer(nomProfil);
	mesProfils.confimerSuppression();
	
	//menuPage.accederMesProfils();
	});
	
  it('Verifier Suppression du profil', function() {	
	mesProfils.attendreAffichage();
	mesProfils.rechercher(nomProfil);
	mesProfils.ProfilInexistant();
  });
});
