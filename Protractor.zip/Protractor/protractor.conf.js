var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
//var globalTimeout = 30000;
var globalTimeout = 3600000;
var date = new Date();

exports.config = {

	onPrepare: function() {
		browser.manage().window().setSize(1280, 1024);
		browser.manage().timeouts().implicitlyWait(globalTimeout);
		global.EC = protractor.ExpectedConditions;
		global.isAngularSite = function(flag){
			browser.ignoreSynchronization = !flag;
		};

		var disableNgAnimate = function() {
			angular.module('disableNgAnimate', []).run(['$animate', function($animate) {
				$animate.enabled(false);
			}]);
		};
		
	   var disableCssAnimate = function() {
		angular
			.module('disableCssAnimate', [])
			.run(function() {
				var style = document.createElement('style');
				style.type = 'text/css';
				style.innerHTML = '* {' +
					'-webkit-transition: none !important;' +
					'-moz-transition: none !important' +
					'-o-transition: none !important' +
					'-ms-transition: none !important' +
					'transition: none !important' +
					'}';
				document.getElementsByTagName('head')[0].appendChild(style);
			});
		};

		browser.addMockModule('disableNgAnimate', disableNgAnimate);
		browser.addMockModule('disableCssAnimate', disableCssAnimate);
			
		global.data = require('./data.js').data;
		var mois = date.getMonth() + 1;
		jasmine.getEnv().addReporter(
			new Jasmine2HtmlReporter({
				
				savePath: 'tests/reports_'+ date.getDate() + mois + '_'+ date.getHours() + '.' + date.getMinutes() + '.' + date.getMinutes() + '/'
			})
		); 
	},

	seleniumAddress: 'http://localhost:4444/wd/hub',
 /* 
  multiCapabilities: [{
		'browserName': 'chrome'
	}, {
		'browserName': 'firefox'
	}],
*/
  
	capabilities: {
		//'browserName': 'chrome'
		//'browserName': 'firefox'
		'browserName': 'internet explorer'

	}, 
	


	suites: {
		nouveauCompte: 'tests/CreerCompte.js',
		ajouterProfil: 'tests/AjouterProfil.js',
		ajouterProfilSurligner: 'tests/AjouterProfilSurligner.js',
		ajouterProfilColorerLigne: 'tests/AjouterProfilColorerLigne.js',
		ajouterProfilColorerSyllabe: 'tests/AjouterProfilColorerSyllabe.js',
		modifierProfil: 'tests/ModifierProfil.js',
		deleguerProfil: 'tests/DeleguerProfil.js',
		supprimerProfil: 'tests/SupprimerProfil.js',
		apercuProfilSurligner: 'tests/ApercuProfilSurligner.js',
		apercuProfilColorerLigne: 'tests/ApercuProfilColorerLigne.js',
		apercuProfilColorerSyllabe: 'tests/ApercuProfilColorerSyllabe.js',
		importDocumentLocal: 'tests/ImportDocumentLocal.js',
		importDocumentWeb: 'tests/ImportDocumentWeb.js',
		modifierTitre: 'tests/ModifierTitreDocument.js',
		creerDocument: 'tests/CreerDocument.js',
		modifierDocument: 'tests/ModifierDocument.js',
		apercuProfil: 'tests/ApercuProfil.js',
		bookmarklet: 'tests/Bookmarklet.js',
		apercuDocument: 'tests/ApercuDocument.js'
	},
  
	allScriptsTimeout: globalTimeout+1000,
	getPageTimeout: globalTimeout+1000,
	jasmineNodeOpts: {
		showColors: true,
		defaultTimeoutInterval: globalTimeout
	}
  
};