var AjouterProfil = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.modifierProfilDiv = element(by.css('div.profile_infos'));
	this.modifierProfilButton = element(by.css('button.rules_edit_btn'));
	this.ajouterProfil = element(by.name('add_profile'));
	this.enregistrerProfil = element(by.id('save_profile'));
	this.enregistrerProfilModif = element(by.id('save_editedProfile'));
	
	this.listStyles = by.repeater('l in profModTagsText track by $index');
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Cliquer sur le bouton modifier de la div de titre
	*/
	this.CliquerSurModifierProfil = function(){
		this.modifierProfilDiv.element(by.css('button.rules_edit_btn')).click();
	};
	
	/**
	* Cliquer sur le bouton d'enregistrement de profil
	* Cas de Création
	*/
	this.CliquerSurEnregistrerProfil = function(){
		this.enregistrerProfil.click();
	};
	
	/**
	* Cliquer sur le bouton d'enregistrement de profil
	* Cas de Modification
	*/
	this.CliquerSurEnregistrerProfilModif = function(){
		this.enregistrerProfilModif.click();
	};
	
	/**
	* Cliquer sur le bouton modifier de l'element en position indiqué dans la liste des styles
	*
	* @param {int} valeur à renseigner
	*/
	this.modifierStyleNb = function(nb){
		element(by.repeater('l in profModTagsText track by $index').row(nb - 1)).element(by.css('button.rules_edit_btn')).click();
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 1
	* Usuellement Titre 1
	*/
	this.modifierStyleTitre1 = function(){
		this.modifierStyleNb(1);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 2
	* Usuellement Sous-Titre 1
	*/
	this.modifierStyleSousTitre1 = function(){
		this.modifierStyleNb(2);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 3
	* Usuellement Titre 2
	*/
	this.modifierStyleTitre2 = function(){
		this.modifierStyleNb(3);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 4
	* Usuellement Sous-Titre 2
	*/
	this.modifierStyleSousTitre2 = function(){
		this.modifierStyleNb(4);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 5
	* Usuellement Titre 3
	*/
	this.modifierStyleTitre3 = function(){
		this.modifierStyleNb(5);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 6
	* Usuellement Titre 4
	*/
	this.modifierStyleTitre4 = function(){
		this.modifierStyleNb(6);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 7
	* Usuellement Paragraphe
	*/
	this.modifierStyleParagraphe = function(){
		this.modifierStyleNb(7);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 8
	* Usuellement Annotation
	*/
	this.modifierStyleAnnotation = function(){
		this.modifierStyleNb(8);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 9
	* Usuellement Citation
	*/
	this.modifierStyleCitation = function(){
		this.modifierStyleNb(9);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 10
	* Usuellement Liste Niveau 1
	*/
	this.modifierStyleListeNiveau1 = function(){
		this.modifierStyleNb(10);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 11
	* Usuellement Entete
	*/
	this.modifierStyleEntete = function(){
		this.modifierStyleNb(11);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 12
	* Usuellement Pied de Page
	*/
	this.modifierStylePiedPage = function(){
		this.modifierStyleNb(12);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 13
	* Usuellement Légende
	*/
	this.modifierStyleLegende = function(){
		this.modifierStyleNb(13);
	};
	
	
	//-------------Creation---------------------------------
	
	/**
	* Cliquer sur le bouton modifier de l'element en position indiqué dans la liste des styles
	*
	* @param {int} valeur à renseigner
	*/
	this.modifierStyleNbCreation = function(nb){
		element(by.repeater('l in defaultStyle.tagsText track by $index').row(nb - 1)).element(by.css('button.rules_edit_btn')).click();
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 1
	* Usuellement Titre 1
	*/
	this.modifierStyleTitre1Creation = function(){
		this.modifierStyleNbCreation(1);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 2
	* Usuellement Sous-Titre 1
	*/
	this.modifierStyleSousTitre1Creation = function(){
		this.modifierStyleNbCreation(2);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 3
	* Usuellement Titre 2
	*/
	this.modifierStyleTitre2Creation = function(){
		this.modifierStyleNbCreation(3);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 4
	* Usuellement Sous-Titre 2
	*/
	this.modifierStyleSousTitre2Creation = function(){
		this.modifierStyleNbCreation(4);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 5
	* Usuellement Titre 3
	*/
	this.modifierStyleTitre3Creation = function(){
		this.modifierStyleNbCreation(5);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 6
	* Usuellement Titre 4
	*/
	this.modifierStyleTitre4Creation = function(){
		this.modifierStyleNbCreation(6);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 7
	* Usuellement Paragraphe
	*/
	this.modifierStyleParagrapheCreation = function(){
		this.modifierStyleNbCreation(7);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 8
	* Usuellement Annotation
	*/
	this.modifierStyleAnnotationCreation = function(){
		this.modifierStyleNbCreation(8);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 9
	* Usuellement Citation
	*/
	this.modifierStyleCitationCreation = function(){
		this.modifierStyleNbCreation(9);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 10
	* Usuellement Liste Niveau 1
	*/
	this.modifierStyleListeNiveau1Creation = function(){
		this.modifierStyleNbCreation(10);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 11
	* Usuellement Entete
	*/
	this.modifierStyleEnteteCreation = function(){
		this.modifierStyleNbCreation(11);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 12
	* Usuellement Pied de Page
	*/
	this.modifierStylePiedPageCreation = function(){
		this.modifierStyleNbCreation(12);
	};
	
	/**
	* Cliquer sur le bouton modifier de du style en position 13
	* Usuellement Légende
	*/
	this.modifierStyleLegendeCreation = function(){
		this.modifierStyleNbCreation(13);
	};
};
module.exports = new AjouterProfil();