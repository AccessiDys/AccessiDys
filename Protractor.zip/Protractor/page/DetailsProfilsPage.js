var DetailsProfils = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	//this.listRegles = element.all(by.repeater('r in regles'));
	var modifierProfil = require('../page/ModifierValeurStylePage.js');
	
	var colorerRouge = 'color: rgb(217, 6, 41);';
	var colorerBleu = 'color: rgb(6, 110, 217);';
	var colorerVert = 'color: rgb(75, 217, 6);';
			
	var surlignerRougeRGB = 'color: rgb(0, 0, 0); background-color: rgb(217, 6, 41);';
	var surlignerBleuRGB = 'color: rgb(0, 0, 0); background-color: rgb(6, 110, 217);';
	var surlignerVertRGB = 'color: rgb(0, 0, 0); background-color: rgb(75, 217, 6);';
		
	var surlignerJaune = 'background-color: rgb(255, 253, 1); color: rgb(0, 0, 0);';
	var surlignerVert = 'background-color: rgb(4, 255, 4); color: rgb(0, 0, 0);';
	var surlignerCyan = 'background-color: rgb(4, 255, 255); color: rgb(0, 0, 0);';	
	
	this.titre1 = 'h1';
	this.soustitre1 = '.sous-titre1';
	this.titre2 = 'h2';
	this.soustitre2 = '.sous-titre2';
	this.titre3 = 'h3';
	this.titre4 = 'h4';
	this.paragraphe = 'p';
	this.annotation = '.annotation';
	this.citation = '.citation';
	this.liste = 'ul';
	this.entetedepage = '.entetedepage';
	this.pieddepage = '.pieddepage';
	this.legende = '.legende';  
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/

	this.getStyle = function(nb, style){
		browser.wait(EC.visibilityOf(element(by.repeater('r in regles').row(nb))));
		// Recupere le style choisi
		return element(by.repeater('r in regles').row(nb)).$(style);
	};
	
	/*-------------------------------------------
		Police
	-------------------------------------------*/
	this.keyPolice = {
		8:0.666667,
		9:0.75,
		10:0.833333,
		11:0.916667,
		12:1,
		14:1.16667,
		16:1.33333,
		18:1.5,
		22:1.83333,
		24:2,
		26:2.16667,
		28:2.33333,
		36:3,
		48:4,
		72:6
	};
	
	/**
	* Recupere la taille de la police en em par rapport à la valeur en point
	*
	* @param {string} taille de la police en point
	*
	* @return {string} taille de la police en em
	*/
	this.getSizeValuePolice = function(key){
		return this.keyPolice[key];
	};
	
	/**
	* Verifie la police dans l'apercu
	*
	* @param {int} numero du style
	* @param {string} identifiant du style
	* @param {string} Nom de la police
	*/
	this.verifierPolice = function(nbStyle, style, name){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain(name);
	};
	
	this.verifierPoliceTitre1 = function(name){
		this.verifierPolice(0, this.titre1 ,name);
	};
	
	this.verifierPoliceSousTitre1 = function(name){
		this.verifierPolice(1, this.soustitre1 ,name);
	};
	
	this.verifierPoliceTitre2 = function(name){
		this.verifierPolice(2, this.titre2 ,name);
	};
	
	this.verifierPoliceSousTitre2 = function(name){
		this.verifierPolice(3, this.soustitre2 ,name);
	};
	
	this.verifierPoliceTitre3 = function(name){
		this.verifierPolice(4, this.titre3 ,name);
	};
	
	this.verifierPoliceTitre4 = function(name){
		this.verifierPolice(5, this.titre4 ,name);
	};
	
	this.verifierPoliceParagraphe = function(name){
		this.verifierPolice(6, this.paragraphe ,name);
	};
	
	this.verifierPoliceAnnotation = function(name){
		this.verifierPolice(7, this.annotation ,name);
	};
	
	this.verifierPoliceCitation = function(name){
		this.verifierPolice(8, this.citation ,name);
	};
	
	this.verifierPoliceListe = function(name){
		this.verifierPolice(9, this.liste ,name);
	};
	
	this.verifierPoliceEnteteDePage = function(name){
		this.verifierPolice(10, this.entetedepage ,name);
	};
	
	this.verifierPolicePiedDePage = function(name){
		this.verifierPolice(11, this.pieddepage ,name);
	};
	
	this.verifierPoliceLegende = function(name){
		this.verifierPolice(12, this.legende ,name);
	};
	
	/*-------------------------------------------
		Taille
	-------------------------------------------*/	
	/**
	* Verifie la taille de la police dans l'apercu
	*
	* @param {int} numero de style	
	* @param {int} Taille de la police
	*/
	this.verifierTaille = function(nbStyle, style, nb){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('font-size: '+this.getSizeValuePolice(nb)+'em');
	};
	
	this.verifierTailleTitre1 = function(name){
		this.verifierTaille(0, this.titre1 ,name);
	};
	
	this.verifierTailleSousTitre1 = function(name){
		this.verifierTaille(1, this.soustitre1 ,name);
	};
	
	this.verifierTailleTitre2 = function(name){
		this.verifierTaille(2, this.titre2 ,name);
	};
	
	this.verifierTailleSousTitre2 = function(name){
		this.verifierTaille(3, this.soustitre2 ,name);
	};
	
	this.verifierTailleTitre3 = function(name){
		this.verifierTaille(4, this.titre3 ,name);
	};
	
	this.verifierTailleTitre4 = function(name){
		this.verifierTaille(5, this.titre4 ,name);
	};
	
	this.verifierTailleParagraphe = function(name){
		this.verifierTaille(6, this.paragraphe ,name);
	};
	
	this.verifierTailleAnnotation = function(name){
		this.verifierTaille(7, this.annotation ,name);
	};
	
	this.verifierTailleCitation = function(name){
		this.verifierTaille(8, this.citation ,name);
	};
	
	this.verifierTailleListe = function(name){
		this.verifierTaille(9, this.liste ,name);
	};
	
	this.verifierTailleEnteteDePage = function(name){
		this.verifierTaille(10, this.entetedepage ,name);
	};
	
	this.verifierTaillePiedDePage = function(name){
		this.verifierTaille(11, this.pieddepage ,name);
	};
	
	this.verifierTailleLegende = function(name){
		this.verifierTaille(12, this.legende ,name);
	};
	
	/*-------------------------------------------
		Interligne
	-------------------------------------------*/
	/**
	* Calcul la valeur de l'interligne en em
	*
	* @param {int} valeur de l'interligne
	*
	* @return {int} valeur de l'interligne en em
	*/
	this.getValueLineHeight = function(nb){
		var number = 1.106 + (nb * 0.18);
		var decPrecision = 1000;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Verifie la valeur de l'interligne
	*
	* @param {int} valeur l'interligne
	*/
	this.verifierInterligne = function(nbStyle, style, nb){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('line-height: '+this.getValueLineHeight(nb)+'em');
	};
	
	this.verifierInterligneTitre1 = function(name){
		this.verifierInterligne(0, this.titre1 ,name);
	};
	
	this.verifierInterligneSousTitre1 = function(name){
		this.verifierInterligne(1, this.soustitre1 ,name);
	};
	
	this.verifierInterligneTitre2 = function(name){
		this.verifierInterligne(2, this.titre2 ,name);
	};
	
	this.verifierInterligneSousTitre2 = function(name){
		this.verifierInterligne(3, this.soustitre2 ,name);
	};
	
	this.verifierInterligneTitre3 = function(name){
		this.verifierInterligne(4, this.titre3 ,name);
	};
	
	this.verifierInterligneTitre4 = function(name){
		this.verifierInterligne(5, this.titre4 ,name);
	};
	
	this.verifierInterligneParagraphe = function(name){
		this.verifierInterligne(6, this.paragraphe ,name);
	};
	
	this.verifierInterligneAnnotation = function(name){
		this.verifierInterligne(7, this.annotation ,name);
	};
	
	this.verifierInterligneCitation = function(name){
		this.verifierInterligne(8, this.citation ,name);
	};
	
	this.verifierInterligneListe = function(name){
		this.verifierInterligne(9, this.liste ,name);
	};
	
	this.verifierInterligneEnteteDePage = function(name){
		this.verifierInterligne(10, this.entetedepage ,name);
	};
	
	this.verifierInterlignePiedDePage = function(name){
		this.verifierInterligne(11, this.pieddepage ,name);
	};
	
	this.verifierInterligneLegende = function(name){
		this.verifierInterligne(12, this.legende ,name);
	};

	/*-------------------------------------------
		Graisse
	-------------------------------------------*/
	/**
	* Verifie que le gras est activé
	*/
	this.verifierGraisseGras = function(nbStyle, style){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('font-weight: bold');
	};
	
	/**
	* Verifie que le gras est désactivé
	*/
	this.verifierGraisseNormal = function(nbStyle, style){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('font-weight: normal');
	};
	
	this.verifierGraisseGrasTitre1 = function(){
		this.verifierGraisseGras(0, this.titre1);
	};
	
	this.verifierGraisseGrasSousTitre1 = function(name){
		this.verifierGraisseGras(1, this.soustitre1 ,name);
	};
	
	this.verifierGraisseGrasTitre2 = function(name){
		this.verifierGraisseGras(2, this.titre2 ,name);
	};
	
	this.verifierGraisseGrasSousTitre2 = function(name){
		this.verifierGraisseGras(3, this.soustitre2 ,name);
	};
	
	this.verifierGraisseGrasTitre3 = function(name){
		this.verifierGraisseGras(4, this.titre3 ,name);
	};
	
	this.verifierGraisseGrasTitre4 = function(name){
		this.verifierGraisseGras(5, this.titre4 ,name);
	};
	
	this.verifierGraisseGrasParagraphe = function(name){
		this.verifierGraisseGras(6, this.paragraphe ,name);
	};
	
	this.verifierGraisseGrasAnnotation = function(name){
		this.verifierGraisseGras(7, this.annotation ,name);
	};
	
	this.verifierGraisseGrasCitation = function(name){
		this.verifierGraisseGras(8, this.citation ,name);
	};
	
	this.verifierGraisseGrasListe = function(name){
		this.verifierGraisseGras(9, this.liste ,name);
	};
	
	this.verifierGraisseGrasEnteteDePage = function(name){
		this.verifierGraisseGras(10, this.entetedepage ,name);
	};
	
	this.verifierGraisseGrasPiedDePage = function(name){
		this.verifierGraisseGras(11, this.pieddepage ,name);
	};
	
	this.verifierGraisseGrasLegende = function(name){
		this.verifierGraisseGras(12, this.legende ,name);
	};
	
	this.verifierGraisseNormalTitre1 = function(){
		this.verifierGraisseNormal(0, this.titre1);
	};
	
	this.verifierGraisseNormalSousTitre1 = function(name){
		this.verifierGraisseNormal(1, this.soustitre1 ,name);
	};
	
	this.verifierGraisseNormalTitre2 = function(name){
		this.verifierGraisseNormal(2, this.titre2 ,name);
	};
	
	this.verifierGraisseNormalSousTitre2 = function(name){
		this.verifierGraisseNormal(3, this.soustitre2 ,name);
	};
	
	this.verifierGraisseNormalTitre3 = function(name){
		this.verifierGraisseNormal(4, this.titre3 ,name);
	};
	
	this.verifierGraisseNormalTitre4 = function(name){
		this.verifierGraisseNormal(5, this.titre4 ,name);
	};
	
	this.verifierGraisseNormalParagraphe = function(name){
		this.verifierGraisseNormal(6, this.paragraphe ,name);
	};
	
	this.verifierGraisseNormalAnnotation = function(name){
		this.verifierGraisseNormal(7, this.annotation ,name);
	};
	
	this.verifierGraisseNormalCitation = function(name){
		this.verifierGraisseNormal(8, this.citation ,name);
	};
	
	this.verifierGraisseNormalListe = function(name){
		this.verifierGraisseNormal(9, this.liste ,name);
	};
	
	this.verifierGraisseNormalEnteteDePage = function(name){
		this.verifierGraisseNormal(10, this.entetedepage ,name);
	};
	
	this.verifierGraisseNormalPiedDePage = function(name){
		this.verifierGraisseNormal(11, this.pieddepage ,name);
	};
	
	this.verifierGraisseNormalLegende = function(name){
		this.verifierGraisseNormal(12, this.legende ,name);
	};

	/*-------------------------------------------
		Espace Mots
	-------------------------------------------*/
	/**
	* Calcul l'espacement des mots en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueWordSpacing = function(nb){
		var number = (nb * 0.18) - 0.18;
		var decPrecision = 100;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Verifie l'espacement des mots
	*
	* @param {int} valeur de l'espacement
	*/
	this.verifierEspaceMots = function(nbStyle, style, nb){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('word-spacing: '+this.getValueWordSpacing(nb)+'em');
	};
	
	this.verifierEspaceMotsTitre1 = function(nb){
		this.verifierEspaceMots(0, this.titre1 ,nb);
	};
	
	this.verifierEspaceMotsSousTitre1 = function(name){
		this.verifierEspaceMots(1, this.soustitre1 ,name);
	};
	
	this.verifierEspaceMotsTitre2 = function(name){
		this.verifierEspaceMots(2, this.titre2 ,name);
	};
	
	this.verifierEspaceMotsSousTitre2 = function(name){
		this.verifierEspaceMots(3, this.soustitre2 ,name);
	};
	
	this.verifierEspaceMotsTitre3 = function(name){
		this.verifierEspaceMots(4, this.titre3 ,name);
	};
	
	this.verifierEspaceMotsTitre4 = function(name){
		this.verifierEspaceMots(5, this.titre4 ,name);
	};
	
	this.verifierEspaceMotsParagraphe = function(name){
		this.verifierEspaceMots(6, this.paragraphe ,name);
	};
	
	this.verifierEspaceMotsAnnotation = function(name){
		this.verifierEspaceMots(7, this.annotation ,name);
	};
	
	this.verifierEspaceMotsCitation = function(name){
		this.verifierEspaceMots(8, this.citation ,name);
	};
	
	this.verifierEspaceMotsListe = function(name){
		this.verifierEspaceMots(9, this.liste ,name);
	};
	
	this.verifierEspaceMotsEnteteDePage = function(name){
		this.verifierEspaceMots(10, this.entetedepage ,name);
	};
	
	this.verifierEspaceMotsPiedDePage = function(name){
		this.verifierEspaceMots(11, this.pieddepage ,name);
	};
	
	this.verifierEspaceMotsLegende = function(name){
		this.verifierEspaceMots(12, this.legende ,name);
	};
	
	/*-------------------------------------------
		Espace Caracteres
	-------------------------------------------*/
	/**
	* Calcul l'espacement des caracteres en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueLetterSpacing = function(nb){
		var number = (nb * 0.12) - 0.12;
		var decPrecision = 100;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Verifie l'espacement des caracteres
	*
	* @param {int} valeur de l'espacemen
	*/
	this.verifierEspaceCaracteres = function(nbStyle, style, nb){
		expect(this.getStyle(nbStyle, style).getAttribute('style')).toContain('letter-spacing: '+this.getValueLetterSpacing(nb)+'em');
	};
	
	this.verifierEspaceCaracteresTitre1 = function(nb){
		this.verifierEspaceCaracteres(0, this.titre1 ,nb);
	};
	
	this.verifierEspaceCaracteresSousTitre1 = function(name){
		this.verifierEspaceCaracteres(1, this.soustitre1 ,name);
	};
	
	this.verifierEspaceCaracteresTitre2 = function(name){
		this.verifierEspaceCaracteres(2, this.titre2 ,name);
	};
	
	this.verifierEspaceCaracteresSousTitre2 = function(name){
		this.verifierEspaceCaracteres(3, this.soustitre2 ,name);
	};
	
	this.verifierEspaceCaracteresTitre3 = function(name){
		this.verifierEspaceCaracteres(4, this.titre3 ,name);
	};
	
	this.verifierEspaceCaracteresTitre4 = function(name){
		this.verifierEspaceCaracteres(5, this.titre4 ,name);
	};
	
	this.verifierEspaceCaracteresParagraphe = function(name){
		this.verifierEspaceCaracteres(6, this.paragraphe ,name);
	};
	
	this.verifierEspaceCaracteresAnnotation = function(name){
		this.verifierEspaceCaracteres(7, this.annotation ,name);
	};
	
	this.verifierEspaceCaracteresCitation = function(name){
		this.verifierEspaceCaracteres(8, this.citation ,name);
	};
	
	this.verifierEspaceCaracteresListe = function(name){
		this.verifierEspaceCaracteres(9, this.liste ,name);
	};
	
	this.verifierEspaceCaracteresEnteteDePage = function(name){
		this.verifierEspaceCaracteres(10, this.entetedepage ,name);
	};
	
	this.verifierEspaceCaracteresPiedDePage = function(name){
		this.verifierEspaceCaracteres(11, this.pieddepage ,name);
	};
	
	this.verifierEspaceCaracteresLegende = function(name){
		this.verifierEspaceCaracteres(12, this.legende ,name);
	};
	
	/*-------------------------------------------
		Coloration
	-------------------------------------------*/
	
	/**
	* Verifie la coloration par mots en Noir 
	*/
	var colorerNoir = 'color: rgb(0, 0, 0);';
	
	this.colorationNoir = function(nb){
		// Recupere le style choisi
		var listeSpan = element(by.repeater('r in regles').row(nb)).$$('span');
		
		// Boucle sur chaque mot du style Titre1		
		listeSpan.each(function(element, index) {
		  // Recupere l'attribut 'style'
		  element.getAttribute('style').then(function (text) {
			expect(text).toEqual(colorerNoir);
		  });
		});
	};
	
	
	/**
	* Verifie la coloration par mots RBV pour le style Titre 1
	*/
	this.alternerCouleur = function(nb, couleur1, couleur2, couleur3){
		browser.wait(EC.visibilityOf(element(by.repeater('r in regles').row(nb))));
		// Recupere le style pour titre 1
		var listeSpan = element(by.repeater('r in regles').row(nb)).$$('span');
		
		// Boucle sur chaque mot du style Titre1		
		listeSpan.each(function(element, index) {
		  // Recupere l'attribut 'style'
		  element.getAttribute('style').then(function (text) {
			// Si la ligne est multiple de 3
			if (index%3 == 0){
				//console.log(index, text, ' rouge');
				// Assertion pour verifier que la couleur est rouge
				expect(text).toEqual(couleur1);
			}
			// Si la ligne est (multiple de 3)+1
			if (index%3 == 1){
				//console.log(index, text, ' bleu');
				// Assertion pour verifier que la couleur est bleue
				expect(text).toEqual(couleur2);
			}
			// Si la ligne est (multiple de 3)+2
			if (index%3 == 2){
				//console.log(index, text, ' vert');
				// Assertion pour verifier que la couleur est verte
				expect(text).toEqual(couleur3);
			}
		  });
		});
	};
	
	this.alternerCouleurLigneStyle = function(nb, couleur1, couleur2, couleur3){
		// Attend que le style s'affiche
		browser.wait(EC.visibilityOf(element(by.repeater('r in regles').row(nb))));
		// Recupere le style choisi
		var listeSpan = element(by.repeater('r in regles').row(nb)).$$('span');
		
		// Déclaration du compteur de ligne
		var lineCount = 0;
 
		// Déclaration des variables pour le calcul de position des elements
		var maxTop = 0, curTop = 0;
		
		listeSpan.each(function(element, index) {
			browser.executeScript("return arguments[0].offsetTop;", element.getWebElement()).then(function (text) {
				// Récuperation de la position verticale
				curTop = text;

				// Le premier element sert de reference pour la position en Y
				if(index === 0) {
					maxTop = curTop;
				}
		 
				// Si la position est differnte de la position actuelle, il y a eu un retour a la ligne
				if(curTop != maxTop) {
			 
					// Mise à jour le maximum
					maxTop = curTop;
			 
					// Mise à jour du compteur de ligne
					lineCount++;
				}
			  
				// Recuperer l'attribut style de l'element
				element.getAttribute('style').then(function (text) {
					//console.log(index, text);
					// Si la ligne est multiple de 3
					if (lineCount%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (lineCount%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleue
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (lineCount%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est verte
						expect(text).toEqual(couleur3);
					}
				});
			});
		});
	};
	
	this.colorationMotRGB = function(nb){
		this.alternerCouleur(nb, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.surlignerMot = function(nb){
		this.alternerCouleur(nb, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.colorationLigneRBV = function(nb){
		this.alternerCouleurLigneStyle(nb, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.surlignageLigneRBV = function(nb){
		this.alternerCouleurLigneStyle(nb, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};	
	
	this.surlignageLigne = function(nb){
		this.alternerCouleurLigneStyle(nb, surlignerJaune, surlignerVert, surlignerCyan);
	};
};
module.exports = new DetailsProfils();