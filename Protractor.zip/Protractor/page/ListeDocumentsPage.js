var ListeDocuments = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.recherche = element(by.css('input.serach_field'));
	this.ajouterDocument = element(by.id('add_documentbtn'));
	this.renommer = element(by.id('save_editedTitle'));
	
	this.listDocuments = element.all(by.repeater("document in listDocument | orderBy:['filename']"));
	
	this.nouveauTitre = element(by.id('inputEmail3'));
	
	this.ouiSupprimer = $('div.modal-footer button.btn_simple');
	
	this.popup_enregistre = element(by.css('div.loader_cover'));
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Cliquer sur le bouton d'ajout de document
	*/
	this.cliquerSurAjouterDocument = function(){
		this.ajouterDocument.click();
	};
	
	/**
	* Renseigne le champs de Recherche
	*
	* @param {string} valeur à renseigner
	*/
	this.rechercher = function(text){
		browser.wait(EC.elementToBeClickable(this.recherche));
		this.recherche.clear();
		this.recherche.sendKeys(text);
	};
	
	/**
	* Verifie qu'un seul document est visible dans la liste
	*/
	this.documentUnique = function(){
		// Effectue un filtre sur la liste des documents
		this.listDocuments.filter(function(elem) {
			// Recupere l'attribut class des elements
			return elem.getAttribute('class').then(function(attr) {
				// Filtre sur la valeur 'ng-scope'
				return attr === 'ng-scope';
			});
		// Compte le nombre de résultat
		}).count().then(function(items) {
			// Assertion pour verifier l'unicité du resultat
			expect(items).toEqual(1);
		});
	};
	
	/**
	* Verifie qu'aucun document n'est visible dans la liste
	*/
	this.documentInexistant = function(){
		// Effectue un filtre sur la liste des documents
		this.listDocuments.filter(function(elem) {
			// Recupere l'attribut class des elements
			return elem.getAttribute('class').then(function(attr) {
				// filtre sur la valeur 'ng-scope'
				return attr === 'ng-scope';
			});
		// Compte le nombre de résultat
		}).count().then(function(items) {
			// Assertion pour verifier l'absence de resultat
			expect(items).toEqual(0);
		});
	};
	
	/**
	* Ouvre le menu action pour le profil "name" et clique sur le bouton "action"
	*
	* @param {string} name : nom du document sur lequel l'action doit etre effectuée
	* @param {by} action : locateur de l'action
	*/
	this.action = function(name, action){
		// Effectue un filtre sur la liste de document
		this.listDocuments.filter(function(row) {
			// Recupere, dans la colone 0 de la ligne, le texte
			return row.$$('td').get(0).getText().then(function(rowName) {
				// Filtre sur les noms qui sont egaux au nom recherché
				return rowName === name;
			});
		// Renvoie un array de taille 1 (si nom unique)
		}).then(function(rows) {
			// Clique sur le bouton action de la ligne filtrée
			rows[0].element(by.className('action_btn')).click();
			// Clique sur la sous action
			rows[0].element(action).click();
		});
	};
	
	/**
	* Accede à l'affichage du document "name"
	*
	* @param {string} valeur à renseigner
	*/
	this.afficher = function(name){
		this.action(name, by.id('show_document'));
	};

	/**
	* Accede à la modification du document "name"
	*
	* @param {string} valeur à renseigner
	*/
	this.modifier = function(name){
		this.action(name, by.id('restructurer_document'));
	};
	
	/**
	* Accede à la suppression du document "name"
	*
	* @param {string} valeur à renseigner
	*/
	this.actionSupprimer = function(name){
		this.action(name, by.id('delete_document'));
	};
	
		//Modifie le titre de document cible et le sélectionne(le bouton action a le même id)
	this.actionModifierTitre = function (name){
		this.action(name, by.id('edit_document'));
	};
	
		//Saisie un nouveau titre
	this.rentrerNouveauTitre = function (nouveauName){
		browser.wait(EC.visibilityOf(this.nouveauTitre), 5000);
		this.nouveauTitre.clear();
		this.nouveauTitre.sendKeys(nouveauName);
	};
	
		//Renomme et enregistre le changement de nom du titre
	this.actionRenommer = function (){
		this.renommer.click();
		browser.wait(EC.invisibilityOf(this.popup_enregistre));
	}
	
	this.ValiderSuppression = function (){
		browser.wait(EC.visibilityOf(this.ouiSupprimer));
		this.ouiSupprimer.click();
		browser.wait(EC.invisibilityOf(this.popup_enregistre));
	}
			
};
module.exports = new ListeDocuments();