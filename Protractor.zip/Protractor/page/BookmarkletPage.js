var Bookmarklet = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/

	this.listElement = element.all(by.repeater('page in content track by $index'));
	this.listElementRow = element(by.repeater('page in content track by $index').row(0));
	
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Attend le double rechargement de la page suite à une action sur un profil
	*/
	this.attendreAffichage = function(){
		browser.wait(EC.presenceOf(this.listElementRow));
	};
	
	
	/**
	* Ouvre le menu action pour le profil "name" et clique sur le bouton "action"
	*
	* @param {string} nom du profil sur lequel l'action doit etre effectué
	* @param {by} locateur de la sous action
	*/
	this.verifierNonVide = function(){
		this.listElement.each(function(el, index) {
		  // Recupere l'attribut 'style'
			  el.$$('span').count().then(function(nb){
				  expect(nb).not.toEqual(0);
			  });
		});
	};
	

	
};
module.exports = new Bookmarklet();