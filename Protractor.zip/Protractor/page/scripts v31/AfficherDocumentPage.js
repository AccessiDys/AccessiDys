var AfficherDocument = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.contenu = element(by.id('adapt-content-1'));
	//this.contenu = element(by.id('editorAdd'));
	
	var colorerRouge = 'color: rgb(217, 6, 41);';
	var colorerBleu = 'color: rgb(6, 110, 217);';
	var colorerVert = 'color: rgb(75, 217, 6);';
	
		
	var surlignerRougeRGB = 'color: rgb(0, 0, 0); background-color: rgb(217, 6, 41);';
	var surlignerBleuRGB = 'color: rgb(0, 0, 0); background-color: rgb(6, 110, 217);';
	var surlignerVertRGB = 'color: rgb(0, 0, 0); background-color: rgb(75, 217, 6);';
	
	var surlignerJaune = 'background-color: rgb(255, 253, 1); color: rgb(0, 0, 0);';
	var surlignerVert = 'background-color: rgb(4, 255, 4); color: rgb(0, 0, 0);';
	var surlignerCyan = 'background-color: rgb(4, 255, 255); color: rgb(0, 0, 0);';	
	
	this.titre1 = 'h1';
	this.soustitre1 = '.sous-titre1';
	this.titre2 = 'h2';
	this.soustitre2 = '.sous-titre2';
	this.titre3 = 'h3';
	this.titre4 = 'h4';
	this.paragraphe = 'p';
	this.annotation = '.annotation';
	this.citation = '.citation';
	this.entetedepage = '.entetedepage';
	this.pieddepage = '.pieddepage';
	this.legende = '.legende';  
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Verifie la coloration par mots RBV pour le style Titre 1
	*/
	this.alternerCouleur = function(style, couleur1, couleur2, couleur3){
		browser.sleep(5000);
		// Recupere le style pour titre 1
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		//var listeSpan = this.contenu.$(style).$$('span');
		var listeP = this.contenu.$$(style);
		
		// Boucle sur chaque mot du style Titre1	
		listeP.each(function(element) {	
			var listeSpan = element.$$('span');
			listeSpan.each(function(elementP, index) {
			  // Recupere l'attribut 'style'
				elementP.getAttribute('style').then(function (text) {
				// Si la ligne est multiple de 3
					if (index%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (index%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleu
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (index%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est vert
						expect(text).toEqual(couleur3);
					}
				});
			});
		});
	};
	
	this.alternerCouleurLigneStyle = function(style, couleur1, couleur2, couleur3){
		browser.sleep(5000);
		// Attend que le style s'affiche
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		var listeSpan = this.contenu.$$(style + '>span');
		
		// Déclaration du compteur de ligne
		var lineCount = 0;
 
		// Déclaration des variables pour le calcul de position des elements
		var maxTop = 0, curTop = 0;
		
		listeSpan.filter(function(elt) {
			// Recupere, dans la colone 0 de la ligne, le texte
			return elt.getText().then(function(eltName) {
				// Filtre sur les noms qui sont egaux au nom recherché
				return eltName != ' ';
			});
		// Renvoie un array de taille 1 (si nom unique)
		}).each(function(element, index) {
			browser.executeScript("return arguments[0].offsetTop;", element.getWebElement()).then(function (text) {
				// Récuperation de la position verticale
				curTop = text;

				// Le premier element sert de reference pour la position en Y
				if(index === 0) {
					maxTop = curTop;
				}
		 
				// Si la position est differnte de la position actuelle, il y a eu un retour a la ligne
				if(curTop != maxTop) {
			 
					// Mise à jour le maximum
					maxTop = curTop;
			 
					// Mise à jour du compteur de ligne
					lineCount++;
				}
			  
				// Recuperer l'attribut style de l'element
				element.getAttribute('style').then(function (text) {
					//console.log(index, text);
					// Si la ligne est multiple de 3
					if (lineCount%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (lineCount%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleue
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (lineCount%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est verte
						expect(text).toEqual(couleur3);
					}
				});
			});
		});
	};
	
	this.colorationLigneRBVTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVPiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, colorerRouge, colorerBleu, colorerVert);
	};
	
	
	
	this.surlignageLigneRBVTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVPiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	
	
	this.surlignageLigneTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLignePiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	
	this.alternerCouleurMotTitre2 = function(){
		this.alternerCouleur(this.titre2, colorerRouge, colorerBleu, colorerVert);
	};
	
};
module.exports = new AfficherDocument();