var AjouterDocument = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.titre = element(by.css('input.input_simple'));
	this.ouvrirDocument = element(by.id('add_documentbtn'));
	this.enregistrer = element(by.id('save_document'));
	this.fermer = element(by.css('a.btn_annuler'));
	this.continuer = element(by.css('div#save-new-modal button.btn_simple'))
	this.textArea = element(by.css('div#editorAdd'));
	this.toolBar = element(by.id('cke_9'));
	
	this.loaderCover = element(by.css('div.loader_cover'));
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Renseigne le titre du document
	*
	* @param {string} valeur à renseigner
	*/
	this.renseignerTitre = function(text){
		//this.titre.clear();
		this.titre.sendKeys(text);
	};
	
	/**
	* Clique sur ouvrir le document
	*/
	this.cliquerSurOuvrirDocument = function(){
		this.ouvrirDocument.click();
	};
	
	/**
	* Clique sur enregistrer le document
	*/
	this.cliquerSurEnregistrer = function(){
		browser.wait(EC.elementToBeClickable(this.enregistrer));
		this.enregistrer.click();
		//browser.wait(EC.invisibilityOf(this.loaderCover));
	};
	
	/**
	* Clique sur Fermer le document
	*/
	this.cliquerSurFermer = function(){
		browser.wait(EC.invisibilityOf(this.loaderCover));
		browser.wait(EC.elementToBeClickable(this.fermer));
		this.fermer.click();
	};
	
	/**
	* Clique sur Continuer
	*/
	this.cliquerSurContinuer = function(){
		browser.wait(EC.elementToBeClickable(this.continuer));
		this.continuer.click();
	};
	
	/**
	* Verifie que la zone de texte n'est pas vide
	*/
	this.zoneTextNonVide = function(){
		browser.wait(EC.visibilityOf(this.textArea));
		this.textArea.$$('p.ng-scope').count().then(function(nb){
			expect(nb).not.toBe(0);
		});
	};
	
	/**
	* Affiche le texte
	*/
	this.getText = function(){
		browser.wait(EC.visibilityOf(this.toolBar));
		this.textArea.getText().then(function(text){
			console.log(text);
		});

	};
	
	/**
	* Ecrit dans la zone de texte
	*
	* @param {string} texte
	*/
	this.setText = function(text){
		browser.wait(EC.visibilityOf(this.toolBar));
		this.textArea.sendKeys(text);
	};
	
	// Verifier profil-------------------------------------------------------------------
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	//this.contenu = element(by.id('adapt-content-1'));
	this.contenu = element(by.id('editorAdd'));
	
	var colorerRouge = 'color: rgb(217, 6, 41);';
	var colorerBleu = 'color: rgb(6, 110, 217);';
	var colorerVert = 'color: rgb(75, 217, 6);';
	var colorerNoir = 'color: rgb(0, 0, 0);';
		
	var surlignerRougeRGB = 'color: rgb(0, 0, 0); background-color: rgb(217, 6, 41);';
	var surlignerBleuRGB = 'color: rgb(0, 0, 0); background-color: rgb(6, 110, 217);';
	var surlignerVertRGB = 'color: rgb(0, 0, 0); background-color: rgb(75, 217, 6);';
	
	var surlignerJaune = 'background-color: rgb(255, 253, 1); color: rgb(0, 0, 0);';
	var surlignerVert = 'background-color: rgb(4, 255, 4); color: rgb(0, 0, 0);';
	var surlignerCyan = 'background-color: rgb(4, 255, 255); color: rgb(0, 0, 0);';	
	
	this.titre1 = 'h1';
	this.soustitre1 = '.sous-titre1';
	this.titre2 = 'h2';
	this.soustitre2 = '.sous-titre2';
	this.titre3 = 'h3';
	this.titre4 = 'h4';
	this.paragraphe = 'p';
	this.annotation = '.annotation';
	this.citation = '.citation';
	this.entetedepage = '.entetedepage';
	this.pieddepage = '.pieddepage';
	this.legende = '.legende';  
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Verifie la coloration par mots en Noir 
	*/
	this.colorationNoir = function(style){
		// Recupere le style pour titre 1
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		var listeSpan = this.contenu.$$(style + '>span');
		
		// Boucle sur chaque mot du style Titre1		
		listeSpan.each(function(element, index) {
		  // Recupere l'attribut 'style'
		  element.getAttribute('style').then(function (text) {
			expect(text).toEqual(colorerNoir);
		  });
		});
	};
	
	this.test = function(style){
		// Recupere le style pour titre 1
		browser.wait(EC.visibilityOf(this.contenu));
		
		var listeSpan2 = this.contenu.$$(style + '>span');
		console.log('size is :' + listeSpan2.length);
		
	};
	
	/**
	* Verifie la coloration par mots RBV
	*/
	this.alternerCouleur = function(style, couleur1, couleur2, couleur3){
		browser.sleep(5000);
		// Recupere le style pour titre 1
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		//var listeSpan = this.contenu.$(style).$$('span');
		var listeP = this.contenu.$$(style);
		
		// Boucle sur chaque mot du style Titre1	
		listeP.each(function(element) {	
			var listeSpan = element.$$('span');
			listeSpan.each(function(elementP, index) {
			  // Recupere l'attribut 'style'
				elementP.getAttribute('style').then(function (text) {
				// Si la ligne est multiple de 3
					if (index%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (index%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleu
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (index%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est vert
						expect(text).toEqual(couleur3);
					}
				});
			});
		});
	};
	
	
	this.alternerCouleurSurligner = function(style, couleur1, couleur2, couleur3){
		browser.sleep(5000);
		// Recupere le style pour titre 1
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		//var listeSpan = this.contenu.$(style).$$('span');
		var listeSpan = this.contenu.$$(style + '>span');
		
		// Boucle sur chaque mot du style Titre1	
	
			listeSpan.each(function(elementP, index) {
			  // Recupere l'attribut 'style'
				elementP.getAttribute('style').then(function (text) {
				// Si la ligne est multiple de 3
					if (index%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (index%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleu
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (index%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est vert
						expect(text).toEqual(couleur3);
					}
				});
			});
	};
	
	this.alternerCouleurLigneStyle = function(style, couleur1, couleur2, couleur3){
		browser.sleep(5000);
		// Attend que le style s'affiche
		browser.wait(EC.visibilityOf(this.contenu));
		// Recupere le style choisi
		var listeSpan = this.contenu.$$(style + '>span');
		
		// Déclaration du compteur de ligne
		var lineCount = 0;
 
		// Déclaration des variables pour le calcul de position des elements
		var maxTop = 0, curTop = 0;
		
		listeSpan.filter(function(elt) {
			// Recupere, dans la colone 0 de la ligne, le texte
			return elt.getText().then(function(eltName) {
				// Filtre sur les noms qui sont egaux au nom recherché
				return eltName != ' ';
			});
		// Renvoie un array de taille 1 (si nom unique)
		}).each(function(element, index) {
			browser.executeScript("return arguments[0].offsetTop;", element.getWebElement()).then(function (text) {
				// Récuperation de la position verticale
				curTop = text;

				// Le premier element sert de reference pour la position en Y
				if(index === 0) {
					maxTop = curTop;
				}
		 
				// Si la position est differnte de la position actuelle, il y a eu un retour a la ligne
				if(curTop != maxTop) {
			 
					// Mise à jour le maximum
					maxTop = curTop;
			 
					// Mise à jour du compteur de ligne
					lineCount++;
				}
			  
				// Recuperer l'attribut style de l'element
				element.getAttribute('style').then(function (text) {
					//console.log(index, text);
					// Si la ligne est multiple de 3
					if (lineCount%3 == 0){
						//console.log(index, text, ' rouge');
						// Assertion pour verifier que la couleur est rouge
						expect(text).toEqual(couleur1);
					}
					// Si la ligne est (multiple de 3)+1
					if (lineCount%3 == 1){
						//console.log(index, text, ' bleu');
						// Assertion pour verifier que la couleur est bleue
						expect(text).toEqual(couleur2);
					}
					// Si la ligne est (multiple de 3)+2
					if (lineCount%3 == 2){
						//console.log(index, text, ' vert');
						// Assertion pour verifier que la couleur est verte
						expect(text).toEqual(couleur3);
					}
				});
			});
		});
	};
	
	this.colorationLigneRBVTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVPiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.colorationLigneRBVLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, colorerRouge, colorerBleu, colorerVert);
	};
	
	
	
	this.surlignageLigneRBVTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVPiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	this.surlignageLigneRBVLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, surlignerRougeRGB, surlignerBleuRGB, surlignerVertRGB);
	};
	
	
	this.alternerCouleurMotTitre1 = function(){
		this.alternerCouleur(this.titre1, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.alternerCouleurMotTitre2 = function(){
		this.alternerCouleur(this.titre2, colorerRouge, colorerBleu, colorerVert);
	};
	
	this.alternerCouleurMotParagraphe = function(){
		this.alternerCouleur(this.paragraphe, colorerRouge, colorerBleu, colorerVert);
	};
	
	// Surlignage JVC
	
	this.surlignageLigneTitre1 = function(){
		this.alternerCouleurLigneStyle(this.titre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneSousTitre1 = function(){
		this.alternerCouleurLigneStyle(this.soustitre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre2 = function(){
		this.alternerCouleurLigneStyle(this.titre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneSousTitre2 = function(){
		this.alternerCouleurLigneStyle(this.soustitre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre3 = function(){
		this.alternerCouleurLigneStyle(this.titre3, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneTitre4 = function(){
		this.alternerCouleurLigneStyle(this.titre4, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneParagraphe = function(){
		this.alternerCouleurLigneStyle(this.paragraphe, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneAnnotation = function(){
		this.alternerCouleurLigneStyle(this.annotation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneCitation = function(){
		this.alternerCouleurLigneStyle(this.citation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneEnteteDePage = function(){
		this.alternerCouleurLigneStyle(this.entetedepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLignePiedDePage = function(){
		this.alternerCouleurLigneStyle(this.pieddepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageLigneLegende = function(){
		this.alternerCouleurLigneStyle(this.legende, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	// Surlignage Mot JVC
	
	this.surlignageMotTitre1 = function(){
		this.alternerCouleurSurligner(this.titre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotSousTitre1 = function(){
		this.alternerCouleurSurligner(this.soustitre1, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotTitre2 = function(){
		this.alternerCouleurSurligner(this.titre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotSousTitre2 = function(){
		this.alternerCouleurSurligner(this.soustitre2, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotTitre3 = function(){
		this.alternerCouleurSurligner(this.titre3, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotTitre4 = function(){
		this.alternerCouleurSurligner(this.titre4, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotParagraphe = function(){
		this.alternerCouleurSurligner(this.paragraphe, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotAnnotation = function(){
		this.alternerCouleurSurligner(this.annotation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotCitation = function(){
		this.alternerCouleurSurligner(this.citation, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotEnteteDePage = function(){
		this.alternerCouleurSurligner(this.entetedepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotPiedDePage = function(){
		this.alternerCouleurSurligner(this.pieddepage, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	this.surlignageMotLegende = function(){
		this.alternerCouleurSurligner(this.legende, surlignerJaune, surlignerVert, surlignerCyan);
	};
	
	
	
	this.colorationNoirTitre1 = function(){
		this.colorationNoir(this.titre1);
	};
	
	this.colorationNoirSousTitre1 = function(){
		this.colorationNoir(this.soustitre1);
	};
	
	this.colorationNoirTitre2 = function(){
		this.colorationNoir(this.titre2);
	};
	
	this.colorationNoirSousTitre2 = function(){
		this.colorationNoir(this.soustitre2);
	};
	
	this.colorationNoirTitre3 = function(){
		this.colorationNoir(this.titre3);
	};
	
	this.colorationNoirTitre4 = function(){
		this.colorationNoir(this.titre4);
	};
	
	this.colorationNoirParagraphe = function(){
		this.colorationNoir(this.paragraphe);
	};
	
	this.colorationNoirAnnotation = function(){
		this.colorationNoir(this.annotation);
	};
	
	this.colorationNoirCitation = function(){
		this.colorationNoir(this.citation);
	};
	
	this.colorationNoirEnteteDePage = function(){
		this.colorationNoir(this.entetedepage);
	};
	
	this.colorationNoirPiedDePage = function(){
		this.colorationNoir(this.pieddepage);
	};
	
	this.colorationNoirLegende = function(){
		this.colorationNoir(this.legende);
	};

	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/

	this.getStyle = function(style){
		browser.wait(EC.visibilityOf(this.textArea));
		// Recupere le style choisi
		return this.textArea.$(style);
		//element(by.repeater('r in regles').row(nb)).$(style);
	};
	
	/*-------------------------------------------
		Police
	-------------------------------------------*/
	this.keyPolice = {
		8:9.333337,
		9:10.5,
		10:11.666667,
		11:12.833333,
		12:14,
		14:16.33337,
		16:18.6667,
		18:21,
		22:25.66667,
		24:28,
		26:30.33333,
		28:32.666667,
		36:42,
		48:56,
		72:84
	};
	
	/**
	* Recupere la taille de la police en em par rapport à la valeur en point
	*
	* @param {string} taille de la police en point
	*
	* @return {string} taille de la police en em
	*/
	this.getSizeValuePolice = function(key){
		return this.keyPolice[key];
	};
	
	/**
	* Verifie la police dans l'apercu
	*
	* @param {int} numero du style
	* @param {string} identifiant du style
	* @param {string} Nom de la police
	*/
	this.verifierPolice = function(style, name){
		expect(this.getStyle(style).getCssValue('font-family')).toEqual(name);
	};
	
	this.verifierPoliceTitre1 = function(name){
		this.verifierPolice(this.titre1 ,name);
	};
	
	this.verifierPoliceParagraphe = function(name){
		this.verifierPolice(this.paragraphe ,name);
	};

	/*-------------------------------------------
		Taille
	-------------------------------------------*/	
	/**
	* Verifie la taille de la police dans l'apercu
	*
	* @param {int} numero de style	
	* @param {int} Taille de la police
	*/
	this.verifierTaille = function( style, nb){
		expect(this.getStyle(style).getCssValue('font-size')).toEqual(this.getSizeValuePolice(nb)+'px');
	};
	
	this.verifierTailleTitre1 = function(name){
		this.verifierTaille(this.titre1 ,name);
	};
	
	this.verifierTailleParagraphe = function(name){
		this.verifierTaille(this.paragraphe ,name);
	};
	
	
	/*-------------------------------------------
		Interligne
	-------------------------------------------*/

	this.keyInterligne = {
		1:0.666667,
		2:0.75,
		3:0.833333,
		4:0.916667,
		5:42,
		6:1.16667,
		7:1.33333,
		8:52.92,
		9:1.83333,
		10:2,
	};
	
	/**
	* Calcul la valeur de l'interligne en em
	*
	* @param {int} valeur de l'interligne
	*
	* @return {int} valeur de l'interligne en em
	*/
	this.getValueLineHeight = function(key){
		return this.keyPolice[key];
	};
	
	/**
	* Verifie la valeur de l'interligne
	*
	* @param {int} valeur l'interligne
	*/
	this.verifierInterligne = function( style, nb){
		expect(this.getStyle(style).getCssValue('line-height')).toEqual((this.getValueLineHeight(nb))+'px');
	};
	
	this.verifierInterligneTitre1 = function(name){
		this.verifierInterligne(this.titre1 ,name);
	};
	
	this.verifierInterligneParagraphe = function(name){
		this.verifierInterligne(this.paragraphe ,name);
	};

	/*-------------------------------------------
		Graisse
	-------------------------------------------*/
	/**
	* Verifie que le gras est activé
	*/
	this.verifierGraisseGras = function( style){
		expect(this.getStyle(style).getCssValue('font-weight')).toEqual('bold');
	};
	
	/**
	* Verifie que le gras est désactivé
	*/
	this.verifierGraisseNormal = function( style){
		expect(this.getStyle(style).getCssValue('font-weight')).toEqual('normal');
	};
	
	this.verifierGraisseGrasTitre1 = function(){
		this.verifierGraisseGras(this.titre1);
	};
	
	this.verifierGraisseNormalParagraphe = function(){
		this.verifierGraisseNormal(this.paragraphe);
	};

	/*-------------------------------------------
		Espace Mots
	-------------------------------------------*/
	/**
	* Calcul l'espacement des mots en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueWordSpacing = function(nb){
		var number = (nb * 0.18) - 0.18;
		var decPrecision = 100;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	this.keyEspaceMot = {
		1:0.666667,
		2:3.36,
		3:0.833333,
		4:0.916667,
		5:1,
		6:1.16667,
		7:1.33333,
		8:52.92,
		9:1.83333,
		10:2,
	};
	
	/**
	* Calcul l'espacement des mots en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueWordSpacing = function(key){
		return this.keyEspaceMot[key];
	};
	
	/**
	* Verifie l'espacement des mots
	*
	* @param {int} valeur de l'espacement
	*/
	this.verifierEspaceMots = function(style, nb){
		expect(this.getStyle(style).getCssValue('word-spacing')).toEqual(this.getValueWordSpacing(nb)+'px');
	};
	
	this.verifierEspaceMotsTitre1 = function(nb){
		this.verifierEspaceMots(this.titre1 ,nb);
	};
	
	this.verifierEspaceMotsParagraphe = function(nb){
		this.verifierEspaceMots(this.paragraphe ,nb);
	};
	
	/*-------------------------------------------
		Espace Caracteres
	-------------------------------------------*/


	
	this.keyEspaceCaractere = {
		1:'normal',
		2:0.75,
		3:'4.48px',
		4:0.916667,
		5:1,
		6:1.16667,
		7:1.33333,
		8:52.92,
		9:1.83333,
		10:2,
	};
	
	/**
	* Calcul l'espacement des caracteres en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueLetterSpacing = function(key){
		return this.keyEspaceCaractere[key];
	};
	
	/**
	* Verifie l'espacement des caracteres
	*
	* @param {int} valeur de l'espacemen
	*/
	this.verifierEspaceCaracteres = function( style, nb){
		expect(this.getStyle(style).getCssValue('letter-spacing')).toEqual(this.getValueLetterSpacing(nb));
	};
	
	this.verifierEspaceCaracteresTitre1 = function(nb){
		this.verifierEspaceCaracteres(this.titre1 ,nb);
	};
	
	this.verifierEspaceCaracteresParagraphe = function(nb){
		this.verifierEspaceCaracteres(this.paragraphe ,nb);
	};
	
	
};
module.exports = new AjouterDocument();