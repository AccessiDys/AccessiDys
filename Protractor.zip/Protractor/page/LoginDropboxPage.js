var LoginDropboxPage = function(){
	this.email = element(by.name('login_email'));
	this.mdp = element(by.name('login_password'));
	this.seConnecter = element(by.class('sign-in-text'));
	
	this.renseignerEmail = function(text){
		this.email.clear();
		this.email.sendKeys(text);
	};
	
	this.renseignerMdp = function(text){
		this.mdp.clear();
		this.mdp.sendKeys(text);
	};
	
	this.cliquerSurSeConnecter = function(){
		this.seConnecter.click();
	};
};
module.exports = LoginDropboxPage;