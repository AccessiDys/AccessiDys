var OuvrirDocument = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.titre = element(by.model('doc.titre'));
	this.lienWeb = element(by.model('lien'));
	this.chemin = element(by.id('docUploadPdf'));
	this.annuler = element(by.name('reset'));
	this.ouvrir = element(by.name('add_Document'));
	
	this.messageErreur = element(by.css('div.msg_erreur'));
	this.loader = element(by.css('div.modal-backdrop'));
	this.modal = element(by.id('addDocumentModal'));
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Renseigne le titre du document
	*
	* @param {string} valeur à renseigner
	*/
	this.renseignerTitre = function(text){
		this.titre.sendKeys(text);
	};
	
	/**
	* Renseigne le chemin local du document
	*
	* @param {string} valeur à renseigner
	*/
	this.renseignerChemin = function(fichier){
		const path = require('path');
		var fileToUpload = '../' + fichier;
		var absolutePath = path.resolve(__dirname, fileToUpload);
		this.chemin.sendKeys(absolutePath);
	};
	
	/**
	* Renseigne l'URL du document
	*
	* @param {string} URL
	*/
	this.renseignerURL = function(url){
		this.lienWeb.sendKeys(url);
	};
	
	/**
	* Clique sur ouvrir le document
	*/
	this.cliquerSurOuvrir = function(){
		this.ouvrir.click();
		//browser.wait(EC.invisibilityOf(this.modal));
		//browser.wait(EC.invisibilityOf(this.loader));
	};
	
	/**
	* Clique sur "Annuler"
	*/
	this.cliquerSurAnnuler = function(){
		this.annuler.click();
	};
	

};
module.exports = new OuvrirDocument();