var LoginPage = function(){
	this.email = element(by.id('email'));
	this.mdp = element(by.id('mdp'));
	this.seConnecter = element(by.name('login_btn'));
	this.creerCompte = element(by.linkText('créez un compte'));
	this.mesDocuments = element(by.id('titreListDocument'));

	this.renseignerEmail = function(text){
		this.email.clear();
		this.email.sendKeys(text);
	};
	
	this.renseignerMdp = function(text){
		//this.mpd.clear();
		this.mdp.sendKeys(text);
	};
	
	this.cliquerSurSeConnecter = function(){
		this.seConnecter.click();
		browser.wait(EC.presenceOf(this.mesDocuments));
		browser.wait(EC.invisibilityOf($('div.loader_cover')));
	};
	
	this.attendreChargment = function(){
		browser.wait(EC.presenceOf(this.mesDocuments));
		browser.wait(EC.invisibilityOf($('div.loader_cover')));
	};

	this.cliquerSurCreerCompte = function(){
		this.creerCompte.click();
	};
};
module.exports = new LoginPage();