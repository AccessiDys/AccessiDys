var MesProfils = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.recherche = element(by.model('query'));
	this.ajouterProfil = element(by.name('add_profile'));
	this.listProfils = element.all(by.repeater('listeProfil in tests track by $index'));
	
	this.boutonAction = element(by.className('action_btn'));
	this.boutonActionSupprimer = element(by.name('delete_profile'));
	this.confirmerSuppression = element(by.name('delete_profile_btn'));
	
	this.emailDestinataire = element(by.id('delegateEmail'));
	this.annulerDelegation = element(by.xpath('//button[@title="Annuler"]'));
	this.envoyer = element(by.xpath('//button[@title="Envoyer"]'));
	
	this.oui = element(by.css('#annuleDelegate button.btn_simple'))
	
	this.messageAjoutOK = element(by.id('addPanel'));
	
	this.loader = element(by.className('fixed_loader'));
	this.menu = element(by.className('actions_menu'));
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Cliquer sur le bouton "Ajouter Profil"
	*/
	this.cliquerSurAjouterProfil = function(){
		this.ajouterProfil.click();
	};
	
	/**
	* Renseigner le champ "Recherche"
	*
	* @param {string} valeur à renseigner
	*/
	this.rechercher = function(text){
		this.attendreAffichage();
		this.recherche.clear();
		this.recherche.sendKeys(text);
	};
	
	/**
	* Attend le double rechargement de la page suite à une action sur un profil
	*/
	this.attendreAffichage = function(){
		browser.wait(EC.presenceOf(element(by.repeater('listeProfil in tests track by $index').row(0))));
		browser.sleep(2000);		
		browser.wait(EC.presenceOf(element(by.repeater('listeProfil in tests track by $index').row(0))));
	};
	
	/**
	* Compte le nombre de ligne visible dans la liste de profil
	*/
	this.nbProfils = function(){
		// Recupere la liste des elements dans le repeater de profil
		this.listProfils.filter(function(elem) {
			// Effectue un filtre sur la class des elements
			return elem.getAttribute('class').then(function(attr) {
				// La classe doit etre visible
				return attr === 'ng-scope';
			});
		// Compte le nombre d'element dans la liste apres le filtre
		}).count().then(function(items) {
			// Affiche le resulat dans la console
			console.log(items);
		});
	};
	
	/**
	* Verifie qu'un seul profil est affiché
	*/
	this.ProfilUnique = function(){
		this.listProfils.filter(function(elem) {
			return elem.getAttribute('class').then(function(attr) {
				return attr === 'ng-scope';
			});
		}).count().then(function(items) {
			expect(items/2).toEqual(1);
		});
	};
	
	/**
	* Verifie qu'aucun profil n'est affiché
	*/
	this.ProfilInexistant = function(){
		this.listProfils.filter(function(elem) {
			return elem.getAttribute('class').then(function(attr) {
				return attr === 'ng-scope';
			});
		}).count().then(function(items) {
			expect(items/2).toEqual(0);
		});
	};
		
	/**
	* Accede à l'apercu du profil 
	*/	
	this.actionApercu = function (name){
		this.action(name, by.name('show_profile'));
		browser.wait(EC.presenceOf($('div.profile_regles')), 5000);
	};
	
	/**
	* Accede à la suppression du profil 
	*/		
	this.actionSupprimer = function (name){
		this.action(name, by.name('delete_profile'));
	};
	
	/**
	* Accede à la délégation du profil 
	*/
	this.actionDeleguer = function (name){
		this.action(name, by.xpath('//a[@title="Déléguer"]'));
	};
	
	/**
	* Accede à l'annulation du profil 
	*/
	this.actionAnnulerDeleguation = function (name){
		this.action(name, by.xpath('//a[@title="Annuler la déléguation"]'));
	};
	
	/**
	* Accede à la modification du profil 
	*/
	this.actionModifier = function (name){
		this.action(name, by.name('edit_profile'));
	};
	
	/**
	* Ouvre le menu action pour le profil "name" et clique sur le bouton "action"
	*
	* @param {string} nom du profil sur lequel l'action doit etre effectué
	* @param {by} locateur de la sous action
	*/
	this.action = function(name, action){
		// Effectue un filtre sur la liste des profils
		this.listProfils.filter(function(row) {
			// Recupere, dans la colone 0 de la ligne, le texte
			return row.$$('td').get(0).getText().then(function(rowName) {
				// Filtre sur les noms qui sont egaux au nom recherché
				return rowName === name;
			});
		// Renvoie un array de taille 1 (si nom unique)
		}).then(function(rows) {
			// Clique sur le bouton action de la ligne filtrée
			rows[0].element(by.className('action_btn')).click();
			// Clique sur la sous action
			rows[0].element(action).click();
		});
	};
	
	/**
	* Clique sur le bouton de confirmation de suppression
	*/
	this.confimerSuppression = function(){
		this.confirmerSuppression.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
	/**
	* Renseigne l'email pour la délégation
	*
	* @param {string} valeur à renseigner
	*/
	this.renseignerEmail = function(name){
		this.emailDestinataire.clear();
		this.emailDestinataire.sendKeys(name);
	};
	
	/**
	* Clique sur le bouton d'envoie d'email et attend le rechargement de la page
	*/
	this.envoyerEmail = function (){
		this.envoyer.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
	/**
	* Clique sur le bouton "Oui" pour l'annulation de la délégation
	*/
	this.cliquerSurOui = function (){
		this.oui.click();
	};
	
	/**
	* Verifie la presence du message de confirmation d'ajout/modification/suppression
	*/
	this.ajoutOK = function(){
		expect(this.messageAjoutOK.isDisplayed()).toBeTrue();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
};
module.exports = new MesProfils();