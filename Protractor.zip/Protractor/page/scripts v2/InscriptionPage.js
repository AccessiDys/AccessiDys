var InscriptionPage = function(){
	this.prenom = element(by.id('fname_etap-one'));
	this.nom = element(by.id('name_etap-one'));
	this.email = element(by.id('email_etap-one'));
	this.mdp = element(by.id('pwd_etap-one'));
	this.confMdp = element(by.id('comfpsw_etap-one'));
	this.suivant = element(by.name('next_one'));
	this.compteExistant = element(by.linkText('J\'ai déjà un compte'));
	this.suivantConfirmation = element(by.name('suivant_five'));
	this.suivantFavoris = element(by.name('suivant_six'));
	this.suivantProfil = element(by.name('suivant_seven'));
	
	this.renseignerPrenom = function(text){
		this.prenom.clear();
		this.prenom.sendKeys(text);
	};
	
	this.renseignerNom = function(text){
		this.nom.clear();
		this.nom.sendKeys(text);
	};
	
	this.renseignerEmail = function(text){
		this.email.clear();
		this.email.sendKeys(text);
	};
	
	this.renseignerMdp = function(text){
		this.mdp.clear();
		this.mdp.sendKeys(text);
	};
	
	this.renseignerConfMdp = function(text){
		this.confMdp.clear();
		this.confMdp.sendKeys(text);
	};
	
	this.cliquerSurSuivant = function(){
		this.suivant.click();
	};
	
	this.cliquerSurcompteExistant = function(){
		this.compteExistant.click();
	};
	
	this.cliquerSuivantConfirmation = function(){
		this.suivantConfirmation.click();
	};
	
	this.cliquerSuivantFavoris = function(){
		this.suivantFavoris.click();
	};
};
module.exports = new InscriptionPage();