var ModifierDocument  = function(){

	this.miseAjourTexte = element(by.id('editorAdd'));
	var verifier = element(by.id('editorAdd'));
	this.enregistrer = element(by.id('save_document'));
	this.fermer = element(by.className('grey_btn pull-right btn_annuler'));
	
	this.loaderCover = element(by.css('div.loader_cover'));
		
	//Remplace le texte
	this.renseignerTexte = function(message){
		browser.sleep(5000);
		browser.wait(EC.invisibilityOf(this.loaderCover));
		browser.wait(EC.visibilityOf(this.miseAjourTexte),5000);
		this.miseAjourTexte.clear();
		this.miseAjourTexte.sendKeys(message);
	};
	
	/**
	* Clique sur enregistrer le document
	*/
	this.cliquerSurEnregistrer = function(){
		browser.sleep(5000);
		browser.wait(EC.elementToBeClickable(this.enregistrer));
		this.enregistrer.click();
		//browser.wait(EC.invisibilityOf(this.loaderCover));
	};
	
	/**
	* Clique sur Fermer le document
	*/
	this.cliquerSurFermer = function(){
		browser.sleep(5000);
		browser.wait(EC.invisibilityOf(this.loaderCover));
		browser.wait(EC.elementToBeClickable(this.fermer));
		this.fermer.click();
		browser.wait(EC.invisibilityOf(this.loaderCover));
	};

	//Vérifie la validité de l'enregistrement
	this.actionVerification = function(verif){
		browser.sleep(5000);
		browser.wait(EC.visibilityOf(this.miseAjourTexte),5000);
		expect(verifier.getText()).toEqual(verif);
	}
	
};
module.exports = new ModifierDocument();