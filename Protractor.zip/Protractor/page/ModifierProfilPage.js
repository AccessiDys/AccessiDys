var ModifierProfil = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.nom = element(by.id('nom_add'));
	this.nomModif = element(by.id('nom_modif'));
	
	
	this.descriptif = element(by.model('profil.descriptif'));
	this.annuler = element(by.xpath('//button[@title="Annuler"]'));
	this.ok = element(by.xpath('//button[@title="Enregistrer"]'));
	this.enregistrerStyle = element(by.xpath('//button[@title="Enregistrer le style"]'));
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Cliquer sur le bouton "OK"
	*/
	this.enregistrer = function(){
		this.ok.click();
	};
	
	/**
	* Cliquer sur le bouton "Enregistrer le style"
	*/
	this.CliquerSurEnregistrerStyle = function(){
		this.enregistrerStyle.click();
	};
	
	/**
	* Renseigne le nom du style
	* Cas de Creation
	*
	* @param {string} valeur à renseigner
	*/
	this.renseignerNom = function(text){
		this.nom.clear();
		this.nom.sendKeys(text);
	};
	
	/**
	* Renseigne le nom du style
	* Cas de Modification
	*
	* @param {string} valeur à renseigner
	*/
	this.modifierNom = function(text){
		this.nomModif.clear();
		this.nomModif.sendKeys(text);
	};
	
};
module.exports = new ModifierProfil();