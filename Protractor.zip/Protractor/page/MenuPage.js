var MenuPage = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.menu = element(by.className('actions_menu'));
	this.mesProfils = element(by.id('profiles_submenu'));
	this.mesDocuments = element(by.id('documents_submenu'));
	this.monCompte = element(by.id('account_submenu'));
	this.bookmarklet = element(by.id('bookmarklet_submenu'));
	this.seDeconnecter = element(by.id('logout_submenu'));
	
	this.options = element.all(by.xpath('//option[@bo-value="profil"]'));
	
	this.loader = element(by.className('fixed_loader'));
	
	
	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	//Cliquer sur Menu & Acceder à la page mes Profils
	this.accederMesProfils = function(){
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
		browser.wait(EC.invisibilityOf(this.loader));
		this.menu.click();
		this.mesProfils.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
	//Cliquer sur Menu & Acceder à la page mes Documents
	this.accederMesDocuments = function(){
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
		this.menu.click();
		this.mesDocuments.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};

	//Cliquer sur Menu & Acceder à la page mon Compte
	this.accederMonCompte = function(){
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
		this.menu.click();
		this.monCompte.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
	//Cliquer sur Menu & Acceder à la page BookMarklet
	this.accederBookmarklet = function(){
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
		this.menu.click();
		this.bookmarklet.click();
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
	};
	
	//Cliquer sur Menu & Se Déconnecter
	this.accederSeDeconnecter = function(){
		browser.wait(EC.invisibilityOf(this.loader));
		browser.wait(EC.elementToBeClickable(this.menu));
		this.menu.click();
		this.seDeconnecter.click();
	};
	
	//Verifie que le nom existe dans le menu déroulant de profils
	this.ProfilActuelExistant = function(name){
		this.options.getText().then(function(itemList) {
			expect(itemList).toContain(name);
		});
	};
	
	
	this.selectionnerProfil = function(name){
		browser.wait(EC.presenceOf(element(by.cssContainingText('option', name))));
		//$('span.customSelectInner').click();
		element(by.cssContainingText('option', name)).click();
	};
	
};
module.exports = new MenuPage();