var CompteDropboxPage = function(){
	this.ok = element(by.id('ok_btn'));
	this.suivant = element(by.name('next_two'));
	this.modal = element(by.id('myModal'));
	
	this.cliquerSurOk = function(){
		browser.wait(EC.visibilityOf(this.ok));
		this.ok.click();
	};
	
	this.cliquerSurSuivant = function(){
		browser.sleep(2000);
		browser.wait(EC.invisibilityOf(this.modal));
		browser.wait(EC.elementToBeClickable(this.suivant));
		this.suivant.click();
	};

};
module.exports = new CompteDropboxPage();