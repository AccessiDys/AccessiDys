var ModifierValeurStyle = function(){
	
	/*-------------------------------------------
		Objets
	-------------------------------------------*/
	this.police = 'add_font';
	this.taille = 'add_size';
	this.interligne = 'add_line_height';
	this.coloration = 'add_color';
	this.graisse = 'add_style';
	this.espaceMots = 'add_space';
	this.espaceCaracteres = 'add_spaceChar';
	this.apercu = $('p.shown-text-edit.ng-binding');
	
	this.descriptif = element(by.model('profil.descriptif'));
	this.annuler = element(by.xpath('//button[@title="Annuler"]'));
	this.ok = element(by.xpath('//button[@title="Enregistrer le style"]'));
	

	/*-------------------------------------------
		Actions
	-------------------------------------------*/
	
	/**
	* Clique sur le bouton "Enregistrer"
	*/
	this.enregistrer = function(){
		this.ok.click();
	};
	
	/**
	* Selectionne l'option 'name' de la liste déroulante 'element'
	*
	* @param {string} texte : id de la liste deroulante
	* @param {string} texte : nom de l'option à séléctionner
	*/
	this.selectionnerOption = function(element, name){
		$('#'+element+' [value="'+name+'"]').click();
	};	

	/*-------------------------------------------
		Police
	-------------------------------------------*/
	this.keyPolice = {
		8:0.666667,
		9:0.75,
		10:0.833333,
		11:0.916667,
		12:1,
		14:1.16667,
		16:1.33333,
		18:1.5,
		22:1.83333,
		24:2,
		26:2.16667,
		28:2.33333,
		36:3,
		48:4,
		72:6
	};
	
	/**
	* Recupere la taille de la police en em par rapport à la valeur en point
	*
	* @param {string} taille de la police en point
	*
	* @return {string} taille de la police en em
	*/
	this.getSizeValuePolice = function(key){
		return this.keyPolice[key];
	};
	
	/**
	* Selectionne la police 'name'
	*
	* @param {string} Nom de la police
	*/
	this.selectionnerPolice = function(name){
		this.selectionnerOption(this.police, name);
	};
	
	/**
	* Verifie la police dans l'apercu
	*
	* @param {string} Nom de la police
	*/
	this.verifierPolice = function(name){
		expect(this.apercu.getAttribute('data-font')).toEqual(name);
		expect(this.apercu.getAttribute('style')).toContain('font-family: '+name);
	};

	/*-------------------------------------------
		Taille
	-------------------------------------------*/	
	/**
	* Selectionne la taille de la police
	*
	* @param {int} Taille de la police
	*/
	this.selectionnerTaille = function(nb){
		this.selectionnerOption(this.taille, nb);
	};
	
	/**
	* Verifie la taille de la police dans l'apercu
	*
	* @param {int} Taille de la police
	*/
	this.verifierTaille = function(nb){
		expect(this.apercu.getAttribute('data-size')).toEqual(nb);
		expect(this.apercu.getAttribute('style')).toContain('font-size: '+this.getSizeValuePolice(nb)+'em');
	};
	
	/*-------------------------------------------
		Interligne
	-------------------------------------------*/
	/**
	* Calcul la valeur de l'interligne en em
	*
	* @param {int} valeur de l'interligne
	*
	* @return {int} valeur de l'interligne en em
	*/
	this.getValueLineHeight = function(nb){
		var number = 1.106 + (nb * 0.18);
		var decPrecision = 1000;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Selectionne la valeur l'interligne
	*
	* @param {int} valeur l'interligne
	*/
	this.selectionnerInterligne = function(nb){
		this.selectionnerOption(this.interligne, nb);
	};
	
	/**
	* Verifie la valeur de l'interligne
	*
	* @param {int} valeur l'interligne
	*/
	this.verifierInterligne = function(nb){
		expect(this.apercu.getAttribute('data-lineheight')).toEqual(nb.toString());
		expect(this.apercu.getAttribute('style')).toContain('line-height: '+this.getValueLineHeight(nb)+'em');
	};

	/*-------------------------------------------
		Coloration
	-------------------------------------------*/
	/**
	* Selectionne la coloration 'name'
	*
	* @param {string} type de coloration
	*/
	this.selectionnerColoration = function(name){
		this.selectionnerOption(this.coloration, name);
	};
	
	/**
	* Verifie la coloration
	*
	* @param {string} Type de coloration
	*/
	this.verifierColoration = function(name){
		expect(this.apercu.getAttribute('data-coloration')).toEqual(name);
	};
	
	var rouge = 'color: rgb(217, 6, 41);';
	var bleu = 'color: rgb(6, 110, 217);';
	var vert = 'color: rgb(75, 217, 6);';
	
	/**
	* Verifie la coloration par mots RBV pour le style Titre 1
	*/
	this.alternerCouleur = function(){
		// Recupere le style pour titre 1
		var listeSpan = element(by.repeater('r in regles').row(0)).$$('span');
		
		// Boucle sur chaque mot du style Titre1		
		listeSpan.each(function(element, index) {
		  // Recupere l'attribut 'style'
		  element.getAttribute('style').then(function (text) {
			// Si la ligne est multiple de 3
			if (index%3 == 0){
				//console.log(index, text, ' rouge');
				// Assertion pour verifier que la couleur est rouge
				expect(text).toEqual(rouge);
			}
			// Si la ligne est (multiple de 3)+1
			if (index%3 == 1){
				//console.log(index, text, ' bleu');
				// Assertion pour verifier que la couleur est bleu
				expect(text).toEqual(bleu);
			}
			// Si la ligne est (multiple de 3)+2
			if (index%3 == 2){
				//console.log(index, text, ' vert');
				// Assertion pour verifier que la couleur est vert
				expect(text).toEqual(vert);
			}
		  });
		});
	};
	
	/*-------------------------------------------
		Graisse
	-------------------------------------------*/
	/**
	* Selectionne la type de graisse
	*
	* @param {string} Type de graisse
	*/
	this.selectionnerGraisse = function(name){
		this.selectionnerOption(this.graisse, name);
	};
	
	/**
	* Verifie que le gras est activé
	*/
	this.verifierGraisseGras = function(){
		expect(this.apercu.getAttribute('data-weight')).toEqual('Gras');
		expect(this.apercu.getAttribute('style')).toContain('font-weight: bold');
	};
	
	/**
	* Verifie que le gras est désactivé
	*/
	this.verifierGraisseNormal = function(){
		expect(this.apercu.getAttribute('data-weight')).toEqual('Normal');
		expect(this.apercu.getAttribute('style')).toContain('font-weight: normal');
	};

	/*-------------------------------------------
		Espace Mots
	-------------------------------------------*/
	/**
	* Calcul l'espacement des mots en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueWordSpacing = function(nb){
		var number = (nb * 0.18) - 0.18;
		var decPrecision = 100;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Selectionne l'espacement des mots
	*
	* @param {int} valeur de l'espacement
	*/
	this.selectionnerEspaceMots = function(nb){
		this.selectionnerOption(this.espaceMots, nb);
	};
	
	/**
	* Verifie l'espacement des mots
	*
	* @param {int} valeur de l'espacement
	*/
	this.verifierEspaceMots = function(nb){
		expect(this.apercu.getAttribute('style')).toContain('word-spacing: '+this.getValueWordSpacing(nb)+'em');
	};
	
	/*-------------------------------------------
		Espace Caracteres
	-------------------------------------------*/
	/**
	* Calcul l'espacement des caracteres en em
	*
	* @param {int} valeur de l'espacement
	*
	* @return {int} valeur de l'espacement en em
	*/
	this.getValueLetterSpacing = function(nb){
		var number = (nb * 0.12) - 0.12;
		var decPrecision = 100;
		return Math.round(number * decPrecision)/decPrecision;
	};
	
	/**
	* Selectionne l'espacement des caracteres
	*
	* @param {int} valeur de l'espacement
	*/
	this.selectionnerEspaceCaracteres = function(nb){
		this.selectionnerOption(this.espaceCaracteres, nb);
	};
	
	/**
	* Verifie l'espacement des caracteres
	*
	* @param {int} valeur de l'espacemen
	*/
	this.verifierEspaceCaracteres = function(nb){
		expect(this.apercu.getAttribute('style')).toContain('letter-spacing: '+this.getValueLetterSpacing(nb)+'em');
	};
};
module.exports = new ModifierValeurStyle();